// const sequelize = require('sequelize')
// const config = require('./environConfig')
// const Logger = require('../utils/logger');
// const logger = new Logger();
// module.exports = new sequelize('ems',config.dbUserName,config.dbPassword,  {
//     host: config.dbHost,
//     dialectOptions: {
//         multipleStatements: true
//     },
//     dialect: 'mysql',
//     timezone: '+05:30', // ✅ Automatically stores & retrieves in IST
//     pool: {
//         max: 5,
//         min: 0,
//         acquire: 30000,
//         idle: 10000
//     }
// })

// const config = require('./environConfig')
// // const config = environConfig[env]; // Get the correct environment config

// module.exports = new Sequelize(config.database, config.username, config.password, {
//     host: config.host,
//     dialect: 'mysql',
//     dialectOptions: {
//         multipleStatements: true,
//     },
//     timezone: '+05:30',
//     pool: {
//         max: 5,
//         min: 0,
//         acquire: 30000,
//         idle: 10000,
//     },
//     logging: (msg) => logger.info(`Sequelize: ${msg}`),
// });



const Sequelize = require('sequelize'); // ✅ Import Sequelize
const { config } = require('./environConfig'); // ✅ Import the environment config
const Logger = require('../utils/logger');

const logger = new Logger(); // ✅ Initialize logger

// ✅ Sequelize connection
const sequelize = new Sequelize(config.database, config.username, config.password, {
    host: config.host,
    dialect: 'mysql',
    dialectOptions: {
        multipleStatements: true,
    },
    useUtc: false,
    timezone: '+05:30',
    
    pool: {
        max: 5,
        min: 0,
        acquire: 30000,
        idle: 10000,
    },
    logging: (msg) => logger.info(`Sequelize: ${msg}`), // ✅ Logs SQL queries
});

module.exports = sequelize; // ✅ Export Sequelize instance
