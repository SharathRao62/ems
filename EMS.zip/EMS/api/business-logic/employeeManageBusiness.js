const { STATUS_CODE, ERR_MESSAGE, ERROR_CODE } = require('../../constants/constant');
const employeeManageService = require('../services/employeeManageService');
const Logger = require('../../utils/logger');
const moment = require('moment');
const momentTimeZone = require('moment-timezone');

module.exports.employeeManage = async (req) => {
    const logger = new Logger(` Product : EMS | Method : employeeRegistration`);

    try {


        let mobileData = await employeeManageService.getData1(['mobile_number']);
        logger.info(`mobileData | ${JSON.stringify(mobileData)}`);

        if (mobileData && mobileData.mobile_number === req.mobile_number) {    // Mobile number already exists
            // You can return an error response here
            return {
                status: STATUS_CODE.BAD_REQUEST,
                message: 'Mobile number already exists'
            }
        } else {
            let reportData = await employeeManageService.getData1(['registration_number']);
            logger.info(`reportData | ${JSON.stringify(reportData)}`);

            let currentNumber = reportData?.registration_number ?? 2025000;
            function registrationNumber() {
                return ++currentNumber;
            }
            let registration_number = registrationNumber()

            const payload = {
                ...req,  // assuming req.body contains the employee data
                registration_number: registration_number, // Add the registration number here
            };

            let employeeData = await employeeManageService.createEmployeeService(payload);
            logger.info(`employeeData | ${JSON.stringify(employeeData)}`);

            return {
                status: STATUS_CODE.SUCCESS,
                registrationNumber: registration_number,
                message: 'Success'
            }
        }

    } catch (error) {
        logger.error(`${ERROR_CODE.API_INTERNAL} | employeeManage |  error | ${errorFormat(error)}`);
        return {
            status: STATUS_CODE.INTERNAL_ERROR,
            message: "Unable to connect to the database:",
            error: ERR_MESSAGE.EMS_API_FAILED,
        }

    }
};