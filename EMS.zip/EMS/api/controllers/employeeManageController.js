const Logger = require("../../utils/logger");
const { writeJson } = require("../../utils/writer");
const { ENTERING_TO, CONTROLLER_METHOD, METHOD } = require('../../constants/constantLogger');
const employeeManageBusiness = require('../business-logic/employeeManageBusiness');
const logger = new Logger(`Product : EMS | Method : EMS_DETAILS `);
logger.info('EMS Enter')

const employeeManage = async (req, res) => {

    const logger = new Logger('Employee Details');
    logger.info(`${ENTERING_TO} ${CONTROLLER_METHOD} ${METHOD.EMPLOYEE_MANAGEMENT} | request ${JSON.stringify(req.body)}`);

    await employeeManageBusiness.employeeManage(req.body).then(response => {
        writeJson(res, response)
    })
}
module.exports = { employeeManage }


// const employeeManage = async (req, res) => {
//     const logger = new Logger('Employee Details');
//     logger.info(`Processing Employee Management | Request: ${JSON.stringify(req.body)}`);

//     const response = await employeeManageBusiness.employeeManage(req.body);
//     res.json(response);
// };

// module.exports = { employeeManage };
