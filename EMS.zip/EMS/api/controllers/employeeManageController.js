const Logger = require("../../utils/logger");
const { writeJson } = require("../../utils/writer");
const logger = new Logger(`Product : EMS | Method : EMS_DETAILS `);
logger.info('EMS Enter')

// const { ERROR_CODE, STATUS_CODE } = require('../../constants/constant');
// const { ENTERING_TO, CONTROLLER_METHOD, METHOD } = require('../../constants/constantLogger');
const employeeManageBusiness = require('../business-logic/employeeManageBusiness');

const employeeManage = async (req, res) => {
    // const logger = new Logger('getHlData', req.body.lead_id, `${METHOD.GET_HL_DATA}`)
    // logger.info(`${ENTERING_TO} ${CONTROLLER_METHOD} | request | ${maskdata(JSON.stringify(req.body))}`)
    await employeeManageBusiness
        .employeeManage(req.body)
        .then(response => {
            // console.log(response);
            writeJson(res, response)
        })

}
module.exports = { employeeManage }