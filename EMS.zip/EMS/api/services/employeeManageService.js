const employee = require('../../models/employee'); // Make sure it's "employee" if that's your model name

async function createEmployeeService(payload) {
    try {
        let employeeAddition = await employee.create(payload)
        // console.log(employeeAddition);
        return employeeAddition
    } catch (error) {
        // logger.error(`createEmployeeService | error | ${error}`);
    }
};

const getMobileData = (condition, columns, logger) => {
    logger.info(`getMobileData: ${JSON.stringify(condition)}`);    // Log the condition properly
    return employee.findOne({
        attributes: columns,
        where: condition,
        raw: true,
    }).catch((error) => {
        logger.error(`getMobileData | error | ${error}`);
        throw error; // Ensure error is properly handled
    });
};

const getRegistrationNumber = (columns, logger) => {
    logger.info(`getRegistrationNumber ${JSON.stringify(columns)}`);
    return employee.findOne({
        attributes: columns,
        order: [['CreatedTime', 'DESC']],
        raw: true,
    }).catch((error) => {
        logger.error(`getRegistrationNumber | error | ${error}`);
        throw error; // Ensure error is properly handled
    });
};

const getEmployeeData = (condition, columns, logger) => {
    logger.info(`getEmployeeData: ${JSON.stringify(condition)}`); // Log the condition properly
    return employee.findOne({
        attributes: columns,
        where: condition,
        raw: true,
    }).catch((error) => {
        logger.error(`getEmployeeData | error | ${error}`);
        throw error; // Ensure error is properly handled
    });
};


module.exports = {
    createEmployeeService,
    getMobileData,
    getRegistrationNumber,
    getEmployeeData,
}
