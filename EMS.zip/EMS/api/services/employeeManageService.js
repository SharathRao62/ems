const employee  = require('../../models/employee'); // Make sure it's "employee" if that's your model name

async function createEmployeeService(payload) {
    try {
        let employeeAddition = await employee.create(payload)
        // console.log(employeeAddition);
        return employeeAddition
    } catch (error) {
        console.log(error);
    }
}

const getData = async (attributes) => {
    try {
        const data = await employee.findOne({
            attributes: attributes,  // attributes should be an array of column names
            raw: true,               // raw: true will return plain data (no Sequelize model instance)
        });
        return data; // Return the fetched data
    } catch (error) {
        console.error('Error fetching data:', error);
        throw error; // You can either throw the error or return a custom error message
    }
};


const getData1 = async (attributes) => {
    try {
        const data = await employee.findOne({
            attributes: attributes,  // attributes should be an array of column names
            order: [['CreatedTime', 'DESC']], // Order by 'CreatedTime' in descending order
            raw: true,               // raw: true will return plain data (no Sequelize model instance)
        });
        return data; // Return the fetched data
    } catch (error) {
        console.error('Error fetching data:', error);
        throw error; // You can either throw the error or return a custom error message
    }
};




module.exports = { createEmployeeService, getData, getData1 }
