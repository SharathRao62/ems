
module.exports = (sequelize, DataTypes) => {
    const user_requested_device = sequelize.define("user_requested_device", {
        id: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        lead_id: DataTypes.STRING,
        name: DataTypes.STRING,
        desk: DataTypes.STRING,
        floor: DataTypes.STRING,
        manager_name: DataTypes.STRING,
        email: DataTypes.STRING,
        request_id: DataTypes.STRING,
        device_name: DataTypes.STRING,
        request_date: DataTypes.DATE,
        global_rnd_no: DataTypes.STRING,
        category: DataTypes.STRING,
        model_number: DataTypes.STRING,
        status: DataTypes.STRING,
        admin_approved_device_at: DataTypes.DATE,
        user_extend_requested_at: DataTypes.DATE,
        user_extend_requested_duration: DataTypes.DATE,
        is_user_extend_request: DataTypes.INTEGER,
        admin_approved_extend_device_at: DataTypes.DATE,
        is_extend_device_approved: DataTypes.INTEGER,
        createdTime: DataTypes.DATE,
        updatedTime: DataTypes.DATE,
    },
        {
            updatedAt: 'updatedTime',
            createdAt: 'createdTime',
            freezeTableName: true,
        });

    return user_requested_device;
}



