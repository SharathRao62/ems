const { STATUS_CODE, ERR_MESSAGE, ERROR_CODE } = require('../../constants/constant');
const { ENTERING_TO, BUSINESS_LOGIC_METHOD, METHOD } = require('../../constants/constantLogger');
const adminService = require('../service/adminService');
const Logger = require('../../submodule/insta_util_submodule/utils/logger');
const { errorFormat } = require('../../submodule/insta_util_submodule/utils/errorFormat');
const moment = require('moment');

module.exports.deviceExtendAdmin = async (req) => {
    const logger = new Logger(`Product : DMS | Method : deviceExtend`);
    logger.info(`${ENTERING_TO} | ${BUSINESS_LOGIC_METHOD} | ${METHOD.USER_REGISTRATION} | userRequestedDevice | ${JSON.stringify(req)}`);

    try {
        const condition = { is_user_extend_request: 1 };

        const deviceExtendApproveData = await adminService.deviceExtendedBtUser(condition, ['name', 'request_id', 'device_name', 'model_number', 'global_rnd_no', 'category', 'user_extend_requested_duration', 'is_user_extend_request'], logger);
        logger.info(`deviceExtendApproveData | ${JSON.stringify(deviceExtendApproveData)}`);

        return {
            status: STATUS_CODE.SUCCESS,
            message: "Extend devices retrieved successfully.",
            data: deviceExtendApproveData
        };

    } catch (error) {
        logger.error(`${ERROR_CODE.API_INTERNAL} | deviceExtend | error | ${errorFormat(error)}`);
        return {
            status: STATUS_CODE.INTERNAL_ERROR,
            message: "Internal Error",
            error: ERR_MESSAGE.EXTEND_DEVICE_API_FAILED
        };
    }
};
