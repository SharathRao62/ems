const datdecryptAES = require('../utils/cryptoUtils');

module.exports = (sequelize, DataTypes) => {
    const login = sequelize.define("user_login", {
        id: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        name: DataTypes.STRING,
        email: DataTypes.STRING,
        password: DataTypes.STRING,
        createdTime: DataTypes.DATE,
        updatedTime: DataTypes.DATE,
    },
        {
            updatedAt: 'updatedTime',
            createdAt: 'createdTime',
            freezeTableName: true,
        });

    const columns = ['password']

    login.afterFind((loginData) => {
        const decryptField = async (record) => {
            for (const key of columns) {
                const value = record[key];

                if (typeof value === 'string' && value.trim() !== '') {
                    try {
                        record[key] = datdecryptAES.decrypt(value);
                    } catch (err) {
                        console.error(`Decryption failed for ${key}: ${err.message}`);
                    }
                }
            }
        };

        if (Array.isArray(loginData)) {
            return Promise.all(loginData.map(decryptField));
        } else if (loginData && typeof loginData === 'object') {
            return decryptField(loginData);
        }
    });



    login.beforeCreate(async (loginData) => {
        if (loginData) {
            await Promise.all(columns.map(async (key) => {
                if (loginData[key]) {
                    loginData[key] = (await datdecryptAES.encrypt(loginData[key])).encryptedData;
                }
                return '';
            }));
        }
    });

    return login;
}


// const datdecryptAES = require('../utils/cryptoUtils');

// module.exports = (sequelize, DataTypes) => {
//   const login = sequelize.define('user_login', {
//     id: {
//       type: DataTypes.INTEGER,
//       primaryKey: true,
//       autoIncrement: true,
//     },
//     name: DataTypes.STRING,
//     email: DataTypes.STRING,
//     password: DataTypes.STRING,
//     createdTime: DataTypes.DATE,
//     updatedTime: DataTypes.DATE,
//   }, {
//     updatedAt: 'updatedTime',
//     createdAt: 'createdTime',
//     freezeTableName: true,
//   });

//   const columns = ['password'];

//   // Decrypt after fetching
//   login.afterFind(async (result) => {
//     const decryptFields = async (record) => {
//       await Promise.all(columns.map(async (key) => {
//         if (record[key]) {
//           const data = await datdecryptAES.decrypt(record[key]);
//           record[key] = data.decryptedData;
//         }
//       }));
//     };

//     if (Array.isArray(result)) {
//       await Promise.all(result.map(decryptFields));
//     } else if (result) {
//       await decryptFields(result);
//     }
//   });

//   // Encrypt before creating
//   login.beforeCreate(async (loginData) => {
//     await Promise.all(columns.map(async (key) => {
//       if (loginData[key]) {
//         const { encryptedData } = await datdecryptAES.encrypt(loginData[key]);
//         loginData[key] = encryptedData;
//       }
//     }));
//   });

//   return login;
// };
