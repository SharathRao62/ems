module.exports = (sequelize, DataTypes) => {
  const auth = sequelize.define('auth', {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    lead_id: DataTypes.STRING,
    jwt_token: DataTypes.STRING,
    updatedTime: DataTypes.DATE,
    createdTime: DataTypes.DATE,

  }, {
    updatedAt: 'updatedTime',
    createdAt: 'createdTime',
    freezeTableName: true,
  });

  return auth;
};