const fs = require('fs');
const path = require('path');
const http = require('http');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = require('express')();
const expressSanitizer = require('express-sanitizer');
// const swaggerTools = require('swagger-tools');
const swaggerTools = require('@axway/swagger-tools');
const swaggerUi = require('swagger-ui-express');
const jsyaml = require('js-yaml');
// eslint-disable-next-line no-unused-vars
const xFrameOptions = require('x-frame-options');
const sts = require('strict-transport-security');
const helmet = require('helmet');
const frameguard = require('frameguard');
const rateLimit = require('express-rate-limit');
const environConfigSubmodule = require('./submodule/insta_config_submodule/config/environConfig');
// const crypt = require('./submodule/insta_util_submodule/utils/feBeEncryptionDecryption');
const sanitizeMiddleware = require('./submodule/insta_util_submodule/middlewares/sanitizeData');
// const isSecurityData = require('./submodule/insta_util_submodule/utils/isgSecurity');
const middlewareChecks = require('./submodule/insta_util_submodule/middlewares/verifyToken');
// eslint-disable-next-line no-unused-vars
const Logger = require('./submodule/insta_util_submodule/utils/logger');
const logger = new Logger();
const serverPort = 6063;

// swaggerRouter configuration
const options = {
  swaggerUi: path.join(__dirname, '/swagger.json'),
  controllers: path.join(__dirname, './api/controllers'),
  useStubs: process.env.NODE_ENV === 'development', // Conditionally turn on stubs (mock mode)
};

const environment = process.env.NODE_ENV;
if (!environment || environment === 'staging' || environment === 'development' || environment === 'qa') {
  logger.debug(`allow cors ::: ${environment}`);
  app.use(cors());
} else if (environment === 'production') {
  logger.debug(`here to block swagger page ::: ${environment}`);
  app.get('/dms/docs/', (req, res) => {
    logger.debug(`here to emit unauthorized ::: ${environment}`);
    res.send('Unauthorized');
  });
}

const limiter = rateLimit({
  windowMs: 1 * 60 * 1000, // 1 minutes
  max: 600, // limit each IP to 100 requests per windowMs
  message:
    'Too many requests created from this IP, please try again later',
});

//  apply to all requests
app.use(limiter);

const globalSTS = sts.getSTS({ 'max-age': { days: 30 } });
app.use(globalSTS);
app.use(helmet());

app.use(helmet.featurePolicy({
  features: {
    vibrate: ["'none'"],
    camera: ["'none'"],
  },
}));


app.use(helmet.referrerPolicy({ policy: 'same-origin' }));

app.use(helmet.frameguard());
app.use(helmet.noCache());
// app.use(helmet.referrerPolicy({ policy: 'same-origin' }))
app.disable('x-powered-by');
app.use(xFrameOptions());
app.use(frameguard({ action: 'deny' }));
app.use(helmet.xssFilter());

app.use(function (req, res, next) {
  res.setHeader(
    'Content-Security-Policy',
    "frame-ancestors *; font-src 'self' https://fonts.googleapis.com https://fonts.gstatic.com; script-src 'self' 'unsafe-inline' 'unsafe-eval' https://cdnjs.cloudflare.com https://www.googletagmanager.com https://dev.visualwebsiteoptimizer.com https://www.google-analytics.com https://connect.facebook.net; media-src;form-action; worker-src 'self';"
  );
  next();
});

// The Swagger document (require it, build it programmatically, fetch it from a URL, ...)
const spec = fs.readFileSync(path.join(__dirname, 'api/swagger.yaml'), 'utf8');
const swaggerDoc = jsyaml.safeLoad(spec);

app.use(bodyParser.json({ limit: '10mb', extended: true }));
app.use(bodyParser.urlencoded({ limit: '10mb', extended: true }));
app.use((err, req, res, next) => {
  // This check makes sure this is a JSON parsing issue, but it might be
  // coming from any middleware, not just body-parser:
  if (err instanceof SyntaxError && err.status === 400 && 'body' in err) {
    return res.status(400).json({ status: 400 }); // Bad request
  }
  next();
});
app.use(expressSanitizer());

app.use(async (request, response, next) => {

  if (request.sanitize(request.headers.host) !== 'localhost') {
    logger.info('x-forward-proto', request.sanitize(request['x-forwarded-proto']));
    if (request.sanitize(request.headers['x-forwarded-proto']) === 'http') {
      logger.info(`https://${request.sanitize(request.headers.host)}${request.sanitize(request.url)}`);
      response.redirect(301, `https://${request.sanitize(request.headers.host)}${request.sanitize(request.url)}`);
    } else {
      logger.info('next');
      next();
    }
  } else {
    next();
  }
});
app.use(async (request, response, next) => {
  logger.debug('PACKET DECRYPTION | url | ', request.url, ' | packet |');
  const { url, body } = request;
  response.url = url;
  if (request.method === 'POST') {
    logger.debug('PACKET DECRYPTION | request url | decrypt the packet');
    try {
      // const febeResp = await crypt.feBeEncDecFuntion(request, response);
      // if (febeResp && febeResp.txnId && febeResp.encKey) {
      //   next();
      // } else {
      //   logger.error('ENCRYPTION DECRYPTION OF PACKET | failed | ');
      //   response.send(400);
      // }
      next(); // Ensuring POST requests proceed if decryption is bypassed
    } catch (error) {
      logger.error('ENCRYPTION DECRYPTION OF PACKET | failed | ', JSON.stringify(error), error);
      response.send(400);
    }
  } else {
    logger.debug('ENCRYPTION DECRYPTION OF PACKET | no body | bipass decryption');
    next();
  }
});

app.use(bodyParser.json({ limit: '10mb', extended: true }));
app.use(bodyParser.urlencoded({ limit: '10mb', extended: true }));
if (process.env.TEST != 'true') {
  app.use(async (req, res, next) => {
    const { url } = req;
    try {
      if (!url.includes('/login') && !url.includes('/request') && !url.includes('/user_registration') && !url.includes('/myDevice') && !url.includes('/deleteUserByAdmin')
      ) {
        sanitizeMiddleware.sanitizeData(req, res);
      }
      next();
    } catch (error) {
      res.status(400).send();
    }
  });
}
if (process.env.TEST != 'true') {
  app.use((req, res, next) => {
    const { url } = req;
    if ((!url.includes('/dms/v1/user_registration')) && (!url.includes('/dms/v1/login')) && (!url.includes('/dms/docs'))) {
      middlewareChecks.verifyToken(req, res, next);
    } else {
      next();
    }
  });
}


swaggerTools.initializeMiddleware(swaggerDoc, (middleware) => {
  app.use(middleware.swaggerMetadata());
  app.use(middleware.swaggerValidator());
  app.use(middleware.swaggerRouter(options));
  app.use('/dms/docs', swaggerUi.serve, swaggerUi.setup(swaggerDoc));


  // Start the server
  const server = http.createServer(app).listen(serverPort, () => {
    const checkDate = new Date();
    logger.info(`Environment : ${environment}`);
    logger.info(`Your server is listening on port %d (http://localhost:${serverPort}) date time ${checkDate}`, serverPort);
    logger.info(`Swagger-ui is available on http://localhost:${serverPort}/dms/docs/`);
  });

  server.keepAliveTimeout = 310 * 10000;
  server.headersTimeout = 320 * 10000;
  server.timeout = 320 * 10000;
});
process.on('uncaughtException', (err) => {
  console.log(err)
  logger.error('DMS EXCEPTION OCCURED ', JSON.stringify(err));
});
module.exports = app;
