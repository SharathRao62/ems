// const { writeJson } = require("../../utils/writer");
// const { ENTERING_TO, CONTROLLER_METHOD, METHOD } = require('../../constants/constantLogger');
// const deviceSearchBusiness = require('../business-logic/deviceSearchBusiness');
// // const utils = require("../../submodule/insta_util_submodule/utils/writer");
// const Logger = require('../../submodule/insta_util_submodule/utils/logger');
// const deviceSearch = async (req, res) => {
//     const logger = new Logger();

//     logger.info(`${ENTERING_TO} ${CONTROLLER_METHOD} ${METHOD.DEVICE_SEARCH} | lead_id: ${req.user.lead_id} | request: ${JSON.stringify(req.body)}`);
//     console.log(req.user, 'oooooooooooooo');

//     try {
//         const response = await deviceSearchBusiness.deviceSearch(req.body);
//         writeJson(res, response);
//     } catch (err) {
//         logger.error(`DEVICE_SEARCH_FAILED: ${err}`);
//         res.status(500).send({ error: "Internal server error" });
//     }
// };


// const deviceSearch = async (req, res) => {
//     const leadId = req.user?.lead_id;

//     if (!leadId) {
//         return res.status(400).send({ error: 'lead_id missing from token' });
//     }

//     const response = await deviceSearchBusiness.deviceSearch(req.body, { leadId });
//     res.json(response);
// };


// const deviceSearch = async (req, res) => {
//     const logger = new Logger();
//     logger.info(`${ENTERING_TO} ${CONTROLLER_METHOD} ${METHOD.DEVICE_SEARCH} | request ${JSON.stringify(req.body)}`);

//     // ✅ Use req.user.lead_id (not req.body.lead_id)
//     const leadId = req.user?.lead_id;
//     if (!leadId) {
//         return res.status(403).json({ error: 'Missing lead_id in verified token' });
//     }

//     try {
//         const response = await deviceSearchBusiness.deviceSearch(leadId);
//         writeJson(res, response);
//     } catch (error) {
//         logger.error(`Error in deviceSearch: ${error.message}`);
//         res.status(500).json({ error: 'Internal server error' });
//     }
// };


// module.exports = { deviceSearch };

// module.exports = { deviceSearch };




// module.exports.deviceSearch = (req, res) => {
//   const logger = new Logger('GENERATE_MIS_HOMELOAN_REPORT', req.body?.lead_id);
//   console.log(req.body, 'oooooooooooooooooooooooooo');
//   console.log("AUTH HEADER:", req.headers.authorization);
//   logger.info(`${ENTERING_TO} ${CONTROLLER_METHOD} | request | ${JSON.stringify(req.body)}`);

//   deviceSearchBusiness.deviceSearch(req.body?.lead_id).then((result) => {
//     logger.info(`lead id | ${req.body?.lead_id} | success |  ${JSON.stringify(result)}`);
//     res.status(200).json(result); // ✅ added missing response
//   })
//     .catch((error) => {
//       logger.info(`lead id | ${req.body?.lead_id} | failed | ${JSON.stringify(error)} | ${error}`);
//       logger.error(`GENERATE_MIS_HOMELOAN_REPORT_FAILED | failed | ${JSON.stringify(error)} | ${error}`);
//       res.status(500).json({
//         status: 500,
//         message: "Internal Error",
//         error: "DEVICE_SEARCH_API_FAILED",
//       }); // ✅ added missing error response
//     });
// };



const Logger = require('../../submodule/insta_util_submodule/utils/logger');
const utils = require("../../submodule/insta_util_submodule/utils/writer");
const {
  ENTERING_TO,
  CONTROLLER_METHOD,METHOD
} = require('../../constants/constantLogger');
const { STATUS_CODE, NO_LEAD, ERR_MESSAGE,ERROR_CODE,EMPTY, } = require('../../constants/constant');
const { maskdata } = require("../../submodule/insta_util_submodule/utils/logMasking");
const fetchErrorCode = require("../../submodule/insta_util_submodule/utils/fetchErrorCode");
const handleErrorCode = require("../../submodule/insta_util_submodule/utils/handleErrorCode.js");
const stageImplementation = require('../../submodule/insta_util_submodule/utils/stageImplementation');
const { errorFormat } = require("../../submodule/insta_util_submodule/utils/errorFormat");
const deviceSearchBusiness = require('../business-logic/deviceSearchBusiness');

const deviceSearch = (req, res) => {
  const logger = new Logger(` Product : ${req.account_type} | Method : GET_DETAILS , ${req.body.lead_id} , ${METHOD.GET_DETAILS} `);
  logger.info(` ${ENTERING_TO} ${CONTROLLER_METHOD} | Request | ${JSON.stringify(req.body)}`);

  console.log(req.body.lead_id,'_____________++++++++++++++++++++++++++++');
  
  deviceSearchBusiness.deviceSearch(req.body)
    .then(async (response) => {
      logger.debug(`Response | ${JSON.stringify(response)}`);
      if (response.stage_description) {
        // eslint-disable-next-line max-len
        await stageImplementation.stage(response.stage_description, req.body.lead_id).catch((error) => {
          logger.error(`error in stageImplementation | ${JSON.stringify(error)} | error | ${error}`);
        });
        delete response.stage_description;
      }
      if (!(response && response.status === STATUS_CODE.SUCCESS)) {
        const errorVal = await fetchErrorCode.sendErrorCode(response, req.body.lead_id || NO_LEAD);
        logger.info(`errorVal | ${JSON.stringify(errorVal)} | ${maskdata(errorVal)}`);
        response.errorCode = (errorVal) ? errorVal.errorCode : EMPTY;
        response.errorCode = await handleErrorCode.handleErrorCode(
          response,
          req.body.lead_id || null, ERR_MESSAGE.GETDETAILS_UNIDENTIFIED_ERROR,
        ).catch((err) => {
          logger.error(`${ERROR_CODE.API_INTERNAL}  error | ${errorFormat(err)}`);
        });
      }
      utils.writeJson(res, response, STATUS_CODE.SUCCESS);
    })
    .catch(async (error) => {
      if (error.stage_description) {
        // eslint-disable-next-line max-len
        await stageImplementation.stage(error.stage_description, req.body.lead_id).catch((err) => {
          logger.error(`error in stageImplementation |${errorFormat(err)}`);
        });
        delete error.stage_description;
      }
      logger.error(`${ERROR_CODE.API_INTERNAL}  error | ${errorFormat(error)} `);
      const errorStatus = (error.status) ? error : { status: STATUS_CODE.INTERNAL_ERROR };
      errorStatus.errorCode = await handleErrorCode.handleErrorCode(
        error,
        req.body.lead_id || null, ERR_MESSAGE.GETDETAILS_UNIDENTIFIED_ERROR,
      ).catch((err) => {
        logger.error(`${ERROR_CODE.API_INTERNAL} | error | ${errorFormat(err)}`);
      });
      utils.writeJson(res, errorStatus);
    });
}

module.exports = {
  deviceSearch,
};





