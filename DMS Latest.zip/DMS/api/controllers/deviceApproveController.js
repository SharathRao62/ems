const Logger = require('../../submodule/insta_util_submodule/utils/logger.js');
const utils = require("../../submodule/insta_util_submodule/utils/writer.js");
const { ENTERING_TO, CONTROLLER_METHOD, METHOD } = require('../../constants/constantLogger.js');
const { STATUS_CODE, NO_LEAD, ERR_MESSAGE, ERROR_CODE, EMPTY, } = require('../../constants/constant.js');
const { maskdata } = require("../../submodule/insta_util_submodule/utils/logMasking.js");
const fetchErrorCode = require("../../submodule/insta_util_submodule/utils/fetchErrorCode.js");
const handleErrorCode = require("../../submodule/insta_util_submodule/utils/handleErrorCode.js");
const stageImplementation = require('../../submodule/insta_util_submodule/utils/stageImplementation.js');
const { errorFormat } = require("../../submodule/insta_util_submodule/utils/errorFormat.js");
const deviceApproveBusiness = require('../business-logic/deviceApproveBusiness');

const deviceApprove = (req, res) => {
    const logger = new Logger(` Product : ${req.account_type} | Method : GET_DETAILS , ${req.body.lead_id} , ${METHOD.GET_DETAILS} `);
    logger.info(` ${ENTERING_TO} ${CONTROLLER_METHOD} | Request | ${JSON.stringify(req.body)}`);

    console.log(req.body.lead_id, '_____________++++++++++++++++++++++++++++');

    deviceApproveBusiness.deviceApprove(req.body)
        .then(async (response) => {
            logger.debug(`Response | ${JSON.stringify(response)}`);
            if (response.stage_description) {
                // eslint-disable-next-line max-len
                await stageImplementation.stage(response.stage_description, req.body.lead_id).catch((error) => {
                    logger.error(`error in stageImplementation | ${JSON.stringify(error)} | error | ${error}`);
                });
                delete response.stage_description;
            }
            if (!(response && response.status === STATUS_CODE.SUCCESS)) {
                const errorVal = await fetchErrorCode.sendErrorCode(response, req.body.lead_id || NO_LEAD);
                logger.info(`errorVal | ${JSON.stringify(errorVal)} | ${maskdata(errorVal)}`);
                response.errorCode = (errorVal) ? errorVal.errorCode : EMPTY;
                response.errorCode = await handleErrorCode.handleErrorCode(
                    response,
                    req.body.lead_id || null, ERR_MESSAGE.GETDETAILS_UNIDENTIFIED_ERROR,
                ).catch((err) => {
                    logger.error(`${ERROR_CODE.API_INTERNAL}  error | ${errorFormat(err)}`);
                });
            }
            utils.writeJson(res, response, STATUS_CODE.SUCCESS);
        })
        .catch(async (error) => {
            if (error.stage_description) {
                // eslint-disable-next-line max-len
                await stageImplementation.stage(error.stage_description, req.body.lead_id).catch((err) => {
                    logger.error(`error in stageImplementation |${errorFormat(err)}`);
                });
                delete error.stage_description;
            }
            logger.error(`${ERROR_CODE.API_INTERNAL}  error | ${errorFormat(error)} `);
            const errorStatus = (error.status) ? error : { status: STATUS_CODE.INTERNAL_ERROR };
            errorStatus.errorCode = await handleErrorCode.handleErrorCode(
                error,
                req.body.lead_id || null, ERR_MESSAGE.GETDETAILS_UNIDENTIFIED_ERROR,
            ).catch((err) => {
                logger.error(`${ERROR_CODE.API_INTERNAL} | error | ${errorFormat(err)}`);
            });
            utils.writeJson(res, errorStatus);
        });
}

module.exports = {
    deviceApprove,
};





