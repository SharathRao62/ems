const db = require('../../models');
const device = db.device;
const login = db.user_login;
const user_requested_device = db.user_requested_device;
const Sequelize = require('sequelize');
const { Op } = Sequelize;


const deleteDevice = async (condition, logger) => {
    try {
        logger.info(`deleteDevice: condition = ${JSON.stringify(condition)}`);

        // Fetch the device before deleting (for logging or return)
        const deviceData = await device.findOne({
            where: condition,
            raw: true,
        });

        if (!deviceData) {
            logger.info(`Device not found for condition: ${JSON.stringify(condition)}`);
            return null;
        }

        // Delete the device
        await device.destroy({
            where: condition,
        });

        logger.info(`Device deleted: ${JSON.stringify(deviceData)}`);
        return deviceData; // Return deleted device info if needed

    } catch (error) {
        logger.error(`deleteDevice | error | ${error}`);
        throw error;
    }
};

const getTotalDeviceCount = async (logger) => {
    try {
        const count = await device.count();
        logger.info(`Total device count: ${count}`);
        return count;
    } catch (error) {
        logger.error(`getTotalDeviceCount | error | ${error}`);
        throw error;
    }
};


const getUserCount = async (logger) => {
    try {
        const count = await login.count();
        logger.info(`Total user count: ${count}`);
        return count;
    } catch (error) {
        logger.error(`getUserCount | error | ${error}`);
        throw error;
    }
};


const getActiveDeviceCount = async (condition, logger) => {
    try {
        const count = await device.count({
            where: condition
        });
        logger.info(`Active device count: ${count}`);
        return count;
    } catch (error) {
        logger.error(`getActiveDeviceCount | error | ${error}`);
        throw error;
    }
};

const getInActiveDeviceCount = async (condition, logger) => {
    try {
        const count = await device.count({
            where: condition
        });
        logger.info(`In Active device count: ${count}`);
        return count;
    } catch (error) {
        logger.error(`getInActiveDeviceCount | error | ${error}`);
        throw error;
    }
};

const deleteUser = async (condition, logger) => {
    try {
        logger.info(`Condition received: ${JSON.stringify(condition)}`);

        if (!condition || typeof condition !== 'object' || Array.isArray(condition)) {
            throw new Error("Invalid condition object passed to deleteUser.");
        }

        const deletedCount = await login.destroy({
            where: condition,
        });

        logger.info(`Deleted user count: ${deletedCount}`);
        return deletedCount;
    } catch (error) {
        logger.error(`deleteUser | error | ${error}`);
        throw error;
    }
};

const userDeviceRequest = (condition, columns, logger) => {
    logger.info(`userDeviceRequest | ${JSON.stringify(condition)}`);
    return user_requested_device.findAll({
        attributes: columns,
        where: condition,
        raw: true,
    }).catch((error) => {
        logger.error(`userDeviceRequest | error | ${error}`);
    });
};

const validateDevice = async (updateData, condition, logger) => {
    try {
        logger.info(`validateDevice | updateData: ${JSON.stringify(updateData)}, condition: ${JSON.stringify(condition)}`);
        const [affectedRows] = await user_requested_device.update(updateData, {
            where: condition,
            individualHooks: true
        });
        logger.info(`validateDevice | Rows updated: ${affectedRows}`);
        return affectedRows;
    } catch (error) {
        logger.error(`validateDevice | error | ${error}`);
        throw error;
    }
};

const validateDeviceDeny = async (updateData, condition, logger) => {
    try {
        logger.info(`validateDeviceDeny | updateData: ${JSON.stringify(updateData)}, condition: ${JSON.stringify(condition)}`);
        const [affectedRows] = await user_requested_device.update(updateData, {
            where: condition,
            individualHooks: true
        });
        logger.info(`validateDeviceDeny | Rows updated: ${affectedRows}`);
        return affectedRows;
    } catch (error) {
        logger.error(`validateDeviceDeny | error | ${error}`);
        throw error;
    }
};

const validateDeviceDetails = async (updateData, condition1, logger) => {
    try {
        logger.info(`validateDeviceDetails | updateData: ${JSON.stringify(updateData)}, condition1: ${JSON.stringify(condition1)}`);
        const [affectedRows] = await device.update(updateData, {
            where: condition1,
            individualHooks: true
        });
        logger.info(`validateDeviceDetails | Rows updated: ${affectedRows}`);
        return affectedRows;
    } catch (error) {
        logger.error(`validateDeviceDetails | error | ${error}`);
        throw error;
    }
};

const getDeviceDetails = (condition, columns, logger) => {
    logger.info(`getDeviceDetails: ${JSON.stringify(condition)}`);
    return user_requested_device.findOne({
        attributes: columns,
        where: condition,
        raw: true,
    }).catch((error) => {
        logger.error(`getDeviceDetails | error | ${error}`);
    });
};


const modifyDevice = (condition, logger) => {
    logger.info(`modifyDevice | ${JSON.stringify(condition)}`);
    return device.findOne({
        where: condition,
        raw: true,
    }).catch((error) => {
        logger.error(`modifyDevice | error | ${error}`);
    });
};


const modifyDeviceUpdate = (condition, updateData, logger) => {
    return device.update(updateData,
        {
            where: condition,
            individualHooks: true,
        }
    ).catch((error) => {
        logger.error(`modifyDeviceUpdate | error | ${error}`);
    });
};





module.exports = {
    deleteDevice,
    getTotalDeviceCount,
    getUserCount,
    getActiveDeviceCount,
    getInActiveDeviceCount,
    deleteUser,
    userDeviceRequest,
    validateDevice,
    validateDeviceDeny,
    validateDeviceDetails,
    getDeviceDetails,
    modifyDevice,
    modifyDeviceUpdate,
}