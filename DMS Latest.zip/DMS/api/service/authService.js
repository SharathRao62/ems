const db = require('../../models');
const auth = db['auth'];

const authData = (leadData, logger) => {
    return auth.create(leadData)
        .then((newRequest) => {
            return newRequest;
        }).catch((error) => {
            logger.error(`authData | error | ${error}`);
        });
};

module.exports = { authData }