const db = require('../../models');
const login = db['user_login']; // access using actual model name

const userLogin = (condition, columns, logger) => {
    logger.info(`userLogin | ${JSON.stringify(condition)}`);
    return login.findOne({
        attributes: columns,
        where: condition,
        raw: true,
    }).catch((error) => {
        logger.error(`userLogin | error | ${error}`);
        throw error; // Re-throw the error to be caught by the calling business logic
    });
};

async function registerUser(key, logger) {
    try {
        logger.info(`registerUser | ${JSON.stringify(key)}`);
        let userRegister = await login.create(key);
        return userRegister;
    } catch (error) {
        logger.error(`registerUser | Error creating employee: ${error}`);
        throw error; // Re-throw the error
    }
}


const userRegistration = (condition, columns, logger) => {
    logger.info(`userRegistration | ${JSON.stringify(condition)}`); // Log the condition properly
    return login.findOne({
        attributes: columns,
        where: condition,
        raw: true,
    }).catch((error) => {
        logger.error(`userRegistration | error | ${error}`);
        throw error; // Re-throw the error
    });
};

// async function registerUser(payload, logger) {
//     try {
//         logger.info(`registerUser | Payload: ${JSON.stringify(payload)}`);
//         let userRegister = await login.create(payload);
//         console.log('User created:', userRegister);
//         return userRegister;
//     } catch (error) {
//         logger.error(`registerUser | Error: ${error.message}`);
//         console.error(error); // <-- important
//         return null;
//     }
// }

module.exports = {
    userLogin,
    registerUser,
    userRegistration,
}