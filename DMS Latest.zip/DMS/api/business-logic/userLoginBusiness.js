const { STATUS_CODE, ERR_MESSAGE, ERROR_CODE } = require('../../constants/constant');
const { ENTERING_TO, BUSINESS_LOGIC_METHOD, METHOD } = require('../../constants/constantLogger');
const Logger = require('../../submodule/insta_util_submodule/utils/logger');
const { errorFormat } = require('../../submodule/insta_util_submodule/utils/errorFormat');
const { jwtSign, generateCustomId } = require('../../submodule/insta_util_submodule/utils/jwt');
const loginService = require('../service/loginService');
const authService = require('../service/authService');

module.exports.userLogin = async (req) => {
    const logger = new Logger(`Product: EMS | Method: userLogin`);

    try {
        logger.info(` ${ENTERING_TO} | ${BUSINESS_LOGIC_METHOD} | ${METHOD.USER_LOGIN} | request |  ${JSON.stringify(req)}`);

        const condition = { email: req?.email };
        const leadId = generateCustomId();
        const payload = { lead_id: leadId };
        const token = jwtSign(payload);

        let userData = await loginService.userLogin(condition, ['email', 'password', 'name'], logger);
        logger.info(`userData | ${JSON.stringify(userData)}`);

        if (!userData) {
            return {
                status: STATUS_CODE.NOT_FOUND,
                message: 'User not found',
            };
        }

        let displayData = {
            name: userData.name,
            email: userData.email,
            token
        }

        let leadData = {
            lead_id: leadId,
            jwt_token: token
        }

        if (req.email === userData.email && req.password === userData.password) {
            let authorizeData = await authService.authData(leadData, logger);
            logger.info(`authorizeData | ${JSON.stringify(authorizeData)}`);

            return {
                status: STATUS_CODE.SUCCESS,
                message: 'Logged in Successfully',
                data: displayData,
            }
        } else {
            return {
                status: 401,
                message: 'Invalid credentials',
            };
        }
    } catch (error) {
        logger.error(`${ERROR_CODE.API_INTERNAL} | userLogin | error | ${errorFormat(error)}`);
        return {
            status: STATUS_CODE.INTERNAL_ERROR,
            message: "Internal Error",
            error: ERR_MESSAGE.USER_LOGIN_API_FAILED,
        };
    }
};