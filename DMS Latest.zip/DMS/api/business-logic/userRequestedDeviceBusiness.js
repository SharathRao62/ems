const { STATUS_CODE, ERR_MESSAGE, ERROR_CODE } = require('../../constants/constant');
const { ENTERING_TO, BUSINESS_LOGIC_METHOD, METHOD } = require('../../constants/constantLogger');
const adminService = require('../service/adminService');
const Logger = require('../../submodule/insta_util_submodule/utils/logger');
const { errorFormat } = require('../../submodule/insta_util_submodule/utils/errorFormat');

module.exports.userRequestedDevice = async (req) => {
    const logger = new Logger(`Product : DMS | Method : deviceExtend`);
    logger.info(`${ENTERING_TO} | ${BUSINESS_LOGIC_METHOD} | ${METHOD.USER_REGISTRATION} | userRequestedDevice | ${JSON.stringify(req)}`);

    try {
        const condition = { status: 'pending' };

        const userRequestedDeviceData = await adminService.userDeviceRequest(condition, ['request_id', 'device_name', 'model_number', 'global_rnd_no', 'category'], logger);
        logger.info(`userRequestedDeviceData | ${JSON.stringify(userRequestedDeviceData)}`);

        return {
            status: STATUS_CODE.SUCCESS,
            message: "Pending devices retrieved successfully.",
            data: userRequestedDeviceData
        };

    } catch (error) {
        logger.error(`${ERROR_CODE.API_INTERNAL} | deviceExtend | error | ${errorFormat(error)}`);
        return {
            status: STATUS_CODE.INTERNAL_ERROR,
            message: "Internal Error",
            error: ERR_MESSAGE.EXTEND_DEVICE_API_FAILED
        };
    }
};
