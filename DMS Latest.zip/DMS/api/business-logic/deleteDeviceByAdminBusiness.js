const { STATUS_CODE, ERR_MESSAGE, ERROR_CODE } = require('../../constants/constant');
const { ENTERING_TO, BUSINESS_LOGIC_METHOD } = require('../../constants/constantLogger');
const adminService = require('../service/adminService');
const Logger = require('../../submodule/insta_util_submodule/utils/logger');
const { errorFormat } = require('../../submodule/insta_util_submodule/utils/errorFormat');

module.exports.deleteDeviceByAdmin = async (req) => {
    const logger = new Logger(`Product : DMS | Method : deleteDeviceByAdmin`);
    logger.info(`${ENTERING_TO} ${BUSINESS_LOGIC_METHOD.deleteDeviceByAdmin}`);

    try {
        const condition = { global_rnd_no: req?.global_rnd_no };

        // Delete device by Admin
        const deviceData = await adminService.deleteDevice(condition, logger);
        logger.info(`deviceData | ${JSON.stringify(deviceData)}`);

        return {
            status: deviceData ? STATUS_CODE.SUCCESS : STATUS_CODE.FAILURE,
            message: deviceData ? "Device deleted successfully" : "No device found to delete",
            data: deviceData ? condition.global_rnd_no : null,
        };

    } catch (error) {
        logger.error(`${ERROR_CODE.API_INTERNAL} | deleteDeviceByAdmin | error | ${errorFormat(error)}`);
        return {
            status: STATUS_CODE.INTERNAL_ERROR,
            message: "Internal Error",
            error: ERR_MESSAGE.EXTEND_DEVICE_API_FAILED
        };
    }
};
