const { STATUS_CODE, ERR_MESSAGE, ERROR_CODE } = require('../../constants/constant');
const { ENTERING_TO, BUSINESS_LOGIC_METHOD } = require('../../constants/constantLogger');
const adminService = require('../service/adminService');
const Logger = require('../../submodule/insta_util_submodule/utils/logger');
const { errorFormat } = require('../../submodule/insta_util_submodule/utils/errorFormat');


module.exports.deviceApprove = async (req) => {
    const logger = new Logger(`Product : DMS | Method : deviceExtend`);
    logger.info(`${ENTERING_TO} ${BUSINESS_LOGIC_METHOD.deviceExtend}`);
    try {
        const condition = {
            request_id: req?.request_id,
            status: 'Pending'
        };
        const updateData = { status: 'Approved' };

        const updatedCount = await adminService.validateDevice(updateData, condition, logger);
        logger.info(`deviceApproveData | Updated rows: ${updatedCount}`);

        if (updatedCount > 0) {
            return {
                status: STATUS_CODE.SUCCESS,
                message: "Device Approved successfully."
            };
        } else {
            return {
                status: STATUS_CODE.FAILED,
                message: "No matching pending device found to approve."
            };
        }
    } catch (error) {
        logger.error(`${ERROR_CODE.API_INTERNAL} | deviceExtend | error | ${errorFormat(error)}`);
        return {
            status: STATUS_CODE.INTERNAL_ERROR,
            message: "Internal Error",
            error: ERR_MESSAGE.EXTEND_DEVICE_API_FAILED
        };
    }
};



