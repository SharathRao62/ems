const { STATUS_CODE, ERR_MESSAGE, ERROR_CODE } = require('../../constants/constant');
const { BUSINESS_LOGIC_METHOD } = require('../../constants/constantLogger');
const getAllDevices = require('../service/adminService');
const Logger = require('../../submodule/insta_util_submodule/utils/logger');
const { errorFormat } = require('../../submodule/insta_util_submodule/utils/errorFormat');

module.exports.deviceCount = async (req) => {
    const logger = new Logger(`Product: DMS | Method: deviceCount`);

    try {
        logger.info(`Entering ${BUSINESS_LOGIC_METHOD} | METHOD: deviceCount | ${JSON.stringify(req)}`);

        const totalDevice = await getAllDevices.getTotalDeviceCount(logger);
        logger.info(`totalDevice | ${JSON.stringify(totalDevice)}`);

        const totalUsers = await getAllDevices.getUserCount(logger);
        logger.info(`totalUsers | ${JSON.stringify(totalUsers)}`);

        const condition = { is_active: 1 };
        const activeDevices = await getAllDevices.getActiveDeviceCount(condition, logger);
        logger.info(`activeDevices | ${JSON.stringify(activeDevices)}`);


        const condition1 = { is_active: 0 };
        const inActiveDevices = await getAllDevices.getInActiveDeviceCount(condition1, logger);
        logger.info(`inActiveDevices | ${JSON.stringify(inActiveDevices)}`);

        let result = {
            total_device: totalDevice,
            total_users: totalUsers,
            active_device: activeDevices,
            inactive_devices: inActiveDevices
        }

        return {
            status: STATUS_CODE.SUCCESS,
            message: 'User Data Updated Successfully',
            data: result,
        };

    }
    catch (error) {
        logger.error(`${ERROR_CODE.API_INTERNAL} | employeeManage | error | ${errorFormat(error)}`);
        return {
            status: STATUS_CODE.INTERNAL_ERROR,
            message: "Internal Error",
            error: ERR_MESSAGE.GET_USER_DETAILS_API_FAILED,
        };
    }
};