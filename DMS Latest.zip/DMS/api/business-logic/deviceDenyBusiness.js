const { STATUS_CODE, ERR_MESSAGE, ERROR_CODE } = require('../../constants/constant');
const { ENTERING_TO, BUSINESS_LOGIC_METHOD } = require('../../constants/constantLogger');
const adminService = require('../service/adminService');
const Logger = require('../../submodule/insta_util_submodule/utils/logger');
const { errorFormat } = require('../../submodule/insta_util_submodule/utils/errorFormat');


module.exports.deviceDeny = async (req) => {
    const logger = new Logger(`Product : DMS | Method : deviceExtend`);
    logger.info(`${ENTERING_TO} ${BUSINESS_LOGIC_METHOD.deviceExtend}`);
    try {
        const condition = {
            request_id: req?.request_id,
            status: 'Pending'
        };
        const updateData = { status: 'Rejected' };

        const updatedCount = await adminService.validateDeviceDeny(updateData, condition, logger);
        logger.info(`deviceDenyData | Updated rows: ${updatedCount}`);

        if (updatedCount > 0) {
            return {
                status: STATUS_CODE.SUCCESS,
                message: "Device Rejected successfully."
            };
        } else {
            return {
                status: STATUS_CODE.FAILED,
                message: "No matching pending device found to deny."
            };
        }
    } catch (error) {
        logger.error(`${ERROR_CODE.API_INTERNAL} | deviceExtend | error | ${errorFormat(error)}`);
        return {
            status: STATUS_CODE.INTERNAL_ERROR,
            message: "Internal Error",
            error: ERR_MESSAGE.EXTEND_DEVICE_API_FAILED
        };
    }
};



