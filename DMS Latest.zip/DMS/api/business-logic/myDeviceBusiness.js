const { STATUS_CODE, ERR_MESSAGE, ERROR_CODE } = require('../../constants/constant');
const { ENTERING_TO, BUSINESS_LOGIC_METHOD } = require('../../constants/constantLogger');
const deviceSearchService = require('../service/deviceSearchService');
const Logger = require('../../submodule/insta_util_submodule/utils/logger');
const { errorFormat } = require('../../submodule/insta_util_submodule/utils/errorFormat');
const Sequelize = require('sequelize');

module.exports.myDevice = async (req) => {
    const logger = new Logger(`Product : DMS | Method : myDevice`);

    try {

        logger.info(` ${ENTERING_TO} ${BUSINESS_LOGIC_METHOD} | METHOD : myDevice | ${JSON.stringify(req)}`);

        const condition = { email: req?.email };

        let deviceData = await deviceSearchService.getMyDevice(condition, ['request_id', 'device_name', 'model_number', 'global_rnd_no', 'category', 'status'], logger);
        logger.info(`deviceData | ${JSON.stringify(deviceData)}`);

        if (!deviceData || deviceData.length === 0) {
            return {
                status: STATUS_CODE.NOT_FOUND,
                message: "No devices found",
                // data: []
            };
        }

        return {
            status: STATUS_CODE.SUCCESS,
            message: "Device Found Successful",
            data: deviceData
        };

    } catch (error) {
        logger.error(`${ERROR_CODE.API_INTERNAL} | myDevice | error | ${errorFormat(error)}`);
        return {
            status: STATUS_CODE.INTERNAL_ERROR,
            message: "Internal Error",
            error: ERR_MESSAGE.DEVICE_SEARCH_API_FAILED
        };
    }
};
