const { STATUS_CODE, ERR_MESSAGE, ERROR_CODE } = require('../../constants/constant');
const { ENTERING_TO, BUSINESS_LOGIC_METHOD } = require('../../constants/constantLogger');
const adminService = require('../service/adminService');
const deviceSearchService = require('../service/deviceSearchService');
const Logger = require('../../submodule/insta_util_submodule/utils/logger');
const { errorFormat } = require('../../submodule/insta_util_submodule/utils/errorFormat');

module.exports.releaseDevice = async (req) => {
    const logger = new Logger(`Product : DMS | Method : releaseDevice`);
    logger.info(`${ENTERING_TO} ${BUSINESS_LOGIC_METHOD.releaseDevice}`);
    try {
        const condition = { request_id: req?.request_id };

        const userData = await deviceSearchService.getDeviceInfo(condition, ['global_rnd_no'], logger);
        logger.info(`userData: ${JSON.stringify(userData)}`);

        if (!userData || !userData.global_rnd_no) {
            logger.info('No global_rnd_no found in userData');
            return {
                status: STATUS_CODE.FAILED,
                message: "Invalid request. global_rnd_no not found."
            };
        }

        const condition1 = { global_rnd_no: userData.global_rnd_no };
        const updateData = { is_active: 0 };

        const updatedCount = await adminService.validateDeviceDetails(updateData, condition1, logger);
        logger.info(`updatedCount | ${userData.global_rnd_no} | Updated rows: ${updatedCount}`);

        if (updatedCount > 0) {
            return {
                status: STATUS_CODE.SUCCESS,
                message: "Device released successfully."
            };
        } else {
            return {
                status: STATUS_CODE.FAILED,
                message: "No matching device found to Release."
            };
        }
    } catch (error) {
        logger.error(`${ERROR_CODE.API_INTERNAL} | deviceExtend | error | ${errorFormat(error)}`);
        return {
            status: STATUS_CODE.INTERNAL_ERROR,
            message: "Internal Error",
            error: ERR_MESSAGE.EXTEND_DEVICE_API_FAILED
        };
    }
};
