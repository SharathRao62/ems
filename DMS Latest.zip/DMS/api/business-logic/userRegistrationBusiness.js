const { STATUS_CODE, ERR_MESSAGE, ERROR_CODE } = require('../../constants/constant');
const { ENTERING_TO, BUSINESS_LOGIC_METHOD, METHOD } = require('../../constants/constantLogger');
const Logger = require('../../submodule/insta_util_submodule/utils/logger');
const { errorFormat } = require('../../submodule/insta_util_submodule/utils/errorFormat');
const { jwtSign, generateCustomId } = require('../../submodule/insta_util_submodule/utils/jwt');
const loginService = require('../service/loginService');

module.exports.registrationUser = async (req) => {
    const logger = new Logger(`Product: EMS | Method: registrationUser`);

    try {
        logger.info(`${ENTERING_TO} | ${BUSINESS_LOGIC_METHOD} | ${METHOD.USER_REGISTRATION} | request | ${JSON.stringify(req)}`);

        const condition = { email: req?.email };

        // Check if the email is already in use
        const emailData = await loginService.userRegistration(condition, ['email'], logger);
        logger.info(`emailData | ${JSON.stringify(emailData)}`);

        if (emailData && emailData.email === req.email) {
            return {
                status: STATUS_CODE.CONFLICT,
                message: 'Email already used',
            };
        }

        const key = {
            email: req.email,
            password: req.password,
            name: req.name
        };

        const employeeData = await loginService.registerUser(key, logger);
        logger.info(`employeeData | ${JSON.stringify(employeeData)}`);

        const payload = {
            lead_id: generateCustomId(),
            email: req.email
        };

        const token = jwtSign(payload);

        return {
            status: STATUS_CODE.SUCCESS,
            message: 'User Registration Successfully',
            data: token
        };
    } catch (error) {
        logger.error(`${ERROR_CODE.API_INTERNAL} | registrationUser | error | ${errorFormat(error)}`);
        return {
            status: STATUS_CODE.INTERNAL_ERROR,
            message: "Internal Error during user registration.",
            error: ERR_MESSAGE.USER_REGISTRATION_API_FAILED,
        };
    }
};
