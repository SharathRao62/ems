const { STATUS_CODE, ERR_MESSAGE, ERROR_CODE } = require('../../constants/constant');
const { ENTERING_TO, BUSINESS_LOGIC_METHOD } = require('../../constants/constantLogger');
const adminService = require('../service/adminService');
const Logger = require('../../submodule/insta_util_submodule/utils/logger');
const { errorFormat } = require('../../submodule/insta_util_submodule/utils/errorFormat');

module.exports.deleteUser = async (req) => {
    const logger = new Logger(`Product : DMS | Method : deviceSearch`);

    try {

        logger.info(` ${ENTERING_TO} ${BUSINESS_LOGIC_METHOD} | METHOD : deviceSearch | ${JSON.stringify(req)}`);

        const condition = { email: req?.email };

        const isDeleted = await adminService.deleteUser(condition, logger);
        logger.info(`isDeleted | ${JSON.stringify(isDeleted)}`);

        return {
            status: isDeleted ? STATUS_CODE.SUCCESS : STATUS_CODE.FAILURE,
            message: isDeleted ? "User deleted successfully" : "No user found to delete",
            data: isDeleted ? condition.email : null,
        };

    } catch (error) {
        logger.error(`${ERROR_CODE.API_INTERNAL} | deviceSearch | error | ${errorFormat(error)}`);
        return {
            status: STATUS_CODE.INTERNAL_ERROR,
            message: "Internal Error",
            error: ERR_MESSAGE.DEVICE_SEARCH_API_FAILED
        };
    }
};
