// const { decrypt256 } = require("../submodule/insta_util_submodule/utils/encryptDecryptAES256");

module.exports = {
  decryptColumns: async (columns, data) => {
    await Promise.all(columns.map(async (key) => {
      try {
        if (data[key]) {
          data[key] = (await decrypt256(data[key])).decryptedData;
        }
      } catch (error) {
      }
    }));
  },
}