const crypto = require('crypto');
const environConfig = require('../config/environConfig');

const algorithm = 'aes-256-cbc';

// Use a 64-character hex string (32 bytes) for the key
const keyString = environConfig.DATA_ENCRYPTION_KEY256.KEY; // 64 hex chars = 32 bytes

// IV remains 32 hex characters (16 bytes)
const ivString = environConfig.DATA_ENCRYPTION_KEY256.IV; // 32 hex chars = 16 bytes

// Convert to Buffers
const key = Buffer.from(keyString, 'hex');
const iv = Buffer.from(ivString, 'hex');

/** Encrypt a plain text string */

function encrypt(text) {
    const cipher = crypto.createCipheriv(algorithm, key, iv);
    let encrypted = cipher.update(text, 'utf8', 'hex');
    encrypted += cipher.final('hex');
    return {
        encryptedData: encrypted,
        key: key.toString('hex'),
        iv: iv.toString('hex')
    };
}

/** Decrypt an encrypted string using default key/IV */

function decrypt(encryptedData, keyHex = key.toString('hex'), ivHex = iv.toString('hex')) {
    if (!encryptedData || typeof encryptedData !== 'string') {
        throw new Error('Invalid encrypted data');
    }
    const decipher = crypto.createDecipheriv(
        algorithm,
        Buffer.from(keyHex, 'hex'),
        Buffer.from(ivHex, 'hex')
    );
    let decrypted = decipher.update(encryptedData, 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    return decrypted;
}

module.exports = {
    encrypt,
    decrypt
};
