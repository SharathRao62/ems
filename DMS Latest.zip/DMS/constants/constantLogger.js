const ENTERING_TO = 'Entering to';
const CONTROLLER_METHOD = 'Controller method';
const BUSINESS_LOGIC_METHOD = 'Business method';
const SERVICE_METHOD = 'Service method';
const UTIL_METHOD = 'Util method';
const FILES = {
  ENCRYPT_DECRYPT: 'encrypt-decrypt',
  JWT: 'jwt',
  ADDRESS_MAPPING: 'addressMApping',
  XML_TO_JS: 'xmlToJs',
};
const EXTERNAL_SERVICE_METHOD = 'External Service method';

const METHOD = {
  JWT_SIGN: 'jwtSign',
  JWT_VERIFY: 'jwtVerify',
  MODULE:"Module",
  GET_DETAILS:'GET_DETAILS',
  BSM:'BSM',
  PAN:'PAN',
  CONTACT:'CONTACT',
  CUSTOMER:'CUSTOMER',
  PRICING_BRE:'PRICING_BRE',

  SHOW_COMMUNICATION_ADDRESS: 'showCommAddressBusiness',
  GET_HL_DATA:"GET_HL_DATA",
  SAVE_RESIDENCE: 'save residence',
  SAVE_ADDITIONAL_DETAILS : 'SAVE_ADDITIONAL_DETAILS',
  GET_PROCESSING_FEE_DETAILS:'getProcessingFeeDetails',
  GET_PAYMENT_RECEIPT:'GET_PAYMENT_RECEIPT',

   //197284 saveHomeLoan
   SAVE_HOMELOAN_OFFER_DETAILS : 'saveHomeLoanOfferDetails',

   GET_THANK_YOU_PAGE_DETAILS : 'Get ThankYou Page details',

   //hlMisReport
   GENERATE_MIS_HOMELOAN_REPORT: 'GENERATE_MIS_HOMELOAN_REPORT',
   HL_MIS_REPORT:'HL_MIS_REPORT',
   PERSON:'PERSON',
   SAVE_SELFEMPLOYEED_DETAILS:'SAVE_SELFEMPLOYEED_DETAILS',
   SAVE_EMAILID_DETAIL:'SAVE_EMAILID_DETAIL',
   PAHL_MIS_REPORT:'PAHL_MIS_REPORT',


   //209254 sanctionLetter
   PA_HL_SANCTION_LETTER: 'PA_HL_SANCTION_LETTER',

   HL_SANCTION_LETTER_GENERATION: 'hlSanctionletterGeneration',
   GENERATE_NON_PA_LAP_MIS_REPORT:'generateNonPaLapMisReport',
   NON_PA_LAP_MIS_REPORT_SERVICE: 'nonPaLapMisReportService',
};

const TABLE_NAME = {
  master_marital_statuses : 'master_marital_statuses',
  master_religion : 'master_religion',
  MASTER_RELATION: 'master_relation',
  RELATION: 'relation',
  MASTER_RESIDENT_TYPE: 'master_resident_type',
  MASTER_DESIGNATIONS: 'master_designations',
  OCCUPATION: 'occupation',
  MASTER_CASTE : 'master_caste',
}

module.exports = {
  ENTERING_TO,
  CONTROLLER_METHOD,
  BUSINESS_LOGIC_METHOD,
  SERVICE_METHOD,
  METHOD,
  UTIL_METHOD,
  FILES,
  EXTERNAL_SERVICE_METHOD,
  TABLE_NAME,
};
