const isTig = process.env.TIG || false;
const { errorFormat } = require("../../insta_util_submodule/utils/errorFormat");
const Logger = require('../../insta_util_submodule/utils/logger');
const dbconfigenv = require('../../insta_config_submodule/config/econfig/dbconfig.json'); 
const logger = new Logger();
logger.info(`isTig tigconfig | ${JSON.stringify(isTig)}`);
console.log('Line 7 tig file',isTig);

let config = {
   development: {
      readWrite: {
        database: 'dms', // **********CHANGEEEEEEEEEEEEEEEEEEEEE
        username: 'Sharath',
        password: 'password',
        host: '127.0.0.1',
        port: '3306',
        dialect: 'mysql',
      },
    },
  };


  const environment = process.env.NODE_ENV || "development";
  if ((isTig === true || isTig === 'true')) {
   config = JSON.parse(process.env.DB_CONFIG);
   logger.info(`dbconfig Data ENVFILE | ${errorFormat(JSON.stringify(config))}`);
  } else {
    config = config[environment];
    logger.info(`dbconfig Data ENVFILE ELSE | ${errorFormat(JSON.stringify(config))}`);
 }

  module.exports = config;

