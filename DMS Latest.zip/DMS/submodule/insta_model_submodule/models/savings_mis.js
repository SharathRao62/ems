module.exports = (sequelize, DataTypes) => {
    const leadAttribute = sequelize.define('savings_mis', {
        savings_mis_id: {
        primaryKey: true,
        allowNull: false,
        type: DataTypes.INTEGER,
        autoIncrement: true,
      },
      lead_id: DataTypes.STRING,
      attribute_name: DataTypes.STRING,
      attribute_value: DataTypes.STRING,
      createdTime: DataTypes.DATE,
      updatedTime: DataTypes.DATE,
      lead_generatedTime: DataTypes.DATE,
      lead_generatedDate: DataTypes.DATE,
  
  
    }, {
      tableName: 'savings_mis',
      updatedAt: 'updatedTime',
      createdAt: 'createdTime',
    });
    return leadAttribute;
  };
  