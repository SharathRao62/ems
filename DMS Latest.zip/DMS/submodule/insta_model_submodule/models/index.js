const fs = require('fs');
const path = require('path');

const indexModel = () => {
  const basename = path.basename(__filename);

  const db = [];
  fs.readdirSync(__dirname)
    .filter(
      (file) => file.indexOf('.') !== 0 && file !== basename && file.slice(-3) === '.js',
    )
    .forEach((file) => {
      db.push(path.join(__dirname, file));
    });
  return db;
};

module.exports = {
  indexModel,
};
