const errorFormat = (error) => {
  if (typeof error === 'string') {
    return error;
  }
  if (error instanceof Error) { // Check if it's a standard Error object
    return `Message: ${error.message}${error.stack ? ` | Stack: ${error.stack}` : ''}`;
  }
  // For other types of objects, try to stringify, but be cautious
  try {
    const str = JSON.stringify(error);
    return str !== '{}' ? str : 'Non-standard error object';
  } catch (e) {
    return 'Could not stringify error object';
  }
};

module.exports = {
  errorFormat,
};
