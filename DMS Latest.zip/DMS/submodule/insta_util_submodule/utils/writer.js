// // const crypt = require('./feBeEncryptionDecryption');
// const environConfig = require('../../../config/environConfig');

// const writeJson = (response, arg1, arg2) => {
//   let code;
//   let payload;
//   const { url } = response;

//   if (arg2 && Number.isInteger(arg2)) {
//     code = arg2;
//   } else if (arg1 && Number.isInteger(arg1)) {
//     code = arg1;
//   }
//   if (code && arg1) {
//     payload = arg1;
//   } else if (arg1) {
//     payload = arg1;
//   }

//   if(arg1 && arg1.errorCode && arg1.errorCode.actCode){
//     response.setHeader('actCode', arg1.errorCode.actCode)
//   }
  
//   if(arg1 && arg1.errorCode && arg1.errorCode.errorCode){
//     payload.errorCode = arg1.errorCode.errorCode
//   }

//   if (!code) {
//     // if no response code given, we default to 200
//     code = 200;
//   }
//   if (typeof payload === 'object') {
//     payload = JSON.stringify(payload, null, 2);
//   } else {
//     payload = payload ? payload.toString() : '';
//   }
//   if (environConfig.ENCRYPTION_BYPASS
//   || url.includes('/eazypayTransactionStatus') || url.includes('/casaUpdateStatusCode')
//   || url == '/instanewesign/digiCamGeneratorCron'
  
// ) {
//     response.writeHead(code, { 'Content-Type': 'application/json' });
//     response.end(payload);
//   } else {
//     try {
//       const key = response.encKey;
//       response.encKey = '';
//       const value = crypt.encrypt(payload, key);
//       const data = JSON.stringify({
//         part1: value,
//         part2: response.txnId,
//       });
//       response.writeHead(code, { 'Content-Type': 'application/json' });
//       response.end(data);
//     } catch(err){
//       // console.error(`Error in fe-be encryption ${JSON.stringify(err)}`);
//     }
//   }
// };

// module.exports = {
//   writeJson,
// };


// const crypt = require('./feBeEncryptionDecryption'); // Uncomment if encryption is re-enabled
const environConfig = require('../../../config/environConfig');

const writeJson = (res, payload, code = 200) => {
  const isExpress = typeof res.status === 'function';

  // Set custom headers if errorCode is present
  if (payload?.errorCode?.actCode) {
    res.setHeader('actCode', payload.errorCode.actCode);
  }
  if (payload?.errorCode?.errorCode) {
    payload.errorCode = payload.errorCode.errorCode;
  }

  // Use Express-style response if available
  if (isExpress) {
    return res.status(code).json(payload);
  }

  // Raw Node.js fallback (for non-Express responses)
  let responsePayload = payload;
  if (typeof payload === 'object') {
    responsePayload = JSON.stringify(payload, null, 2);
  } else if (payload) {
    responsePayload = payload.toString();
  } else {
    responsePayload = '';
  }

  // Encryption logic bypassed based on config or URL (legacy support)
  const url = res.url || '';
  if (
    environConfig.ENCRYPTION_BYPASS ||
    url.includes('/eazypayTransactionStatus') ||
    url.includes('/casaUpdateStatusCode') ||
    url === '/instanewesign/digiCamGeneratorCron'
  ) {
    res.writeHead(code, { 'Content-Type': 'application/json' });
    return res.end(responsePayload);
  }

  // Optional encrypted payload block (disabled for Swagger compatibility)
  // try {
  //   const key = res.encKey;
  //   res.encKey = '';
  //   const encrypted = crypt.encrypt(responsePayload, key);
  //   const data = JSON.stringify({
  //     part1: encrypted,
  //     part2: res.txnId,
  //   });
  //   res.writeHead(code, { 'Content-Type': 'application/json' });
  //   return res.end(data);
  // } catch (err) {
  //   console.error(`Error in fe-be encryption: ${JSON.stringify(err)}`);
  // }

  // Default fallback if encryption is skipped
  res.writeHead(code, { 'Content-Type': 'application/json' });
  return res.end(responsePayload);
};

module.exports = {
  writeJson,
};
