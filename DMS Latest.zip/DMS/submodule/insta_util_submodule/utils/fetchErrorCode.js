/* eslint-disable max-len */
const Logger = require('./logger');

const logger = new Logger();
const fetchErrorData = require('../api/service/fetchErrorCodeService');
const CONSTANTS = require('../../insta_constants_submodule/constants/constant');

const fetchErrorCode = async (error, leadId, personId) => {
  logger.debug(`FETCH ERROR CODE | leadId | ${leadId} | ERROR CODE DATA | ${error} | ${JSON.stringify(error)} `);
  try {
    const errorData = await fetchErrorData.fetchDataFromErrorCodeTable(error);
    let errCode = {
      error_code: 'GENERIC_ERROR_CODE',
      act_code: 'GENERIC_ACT_CODE'
    };

    if (errorData && errorData.length > 0) {
      errCode = {
        error_code: errorData[0].error_code,
        act_code: errorData[0].act_code
      };
    }

    // If you still want to log something (without DB)
    if (leadId !== 'noLead') {
      logger.debug(`FETCH ERROR CODE | leadId | ${leadId} | personId | ${personId}`);
    }

    return errCode;
  } catch (err) {
    logger.error(`${CONSTANTS.ERROR_CODE.API_INTERNAL} | FETCH ERROR CODE | leadId | ${leadId} | ERROR RESPONSE RECIEVED CATCH BLOCK | ${err} | ${JSON.stringify(err)}`);
    return CONSTANTS.EMPTY;
  }
};

const sendErrorCode = async (response, leadId, personId) => {
  logger.debug(`SEND ERROR CODE | leadId | ${leadId} | RESPONSE |  ${JSON.stringify(response)}`);
  if (response && !response.error) {
    const errCodeData = await fetchErrorCode(CONSTANTS.ERR_MESSAGE.UNIDENTIFIED_ERROR, leadId, personId);
    logger.debug(`SEND ERROR CODE | leadId | ${leadId} | ERROR CODE DATA |  ${JSON.stringify(errCodeData)}`);
    return new Promise((resolve) => resolve({ status: response.status, errorCode: errCodeData.error_code, actCode: errCodeData.act_code }));
  // eslint-disable-next-line no-else-return
  } else {
    const errCodeData = await fetchErrorCode(response.error, leadId, personId);
    logger.debug(`SEND ERROR CODE | leadId | ${leadId} | ERROR CODE DATA |  ${JSON.stringify(errCodeData)}`);
    return new Promise((resolve) => resolve({ status: response.status, errorCode: errCodeData.error_code, actCode: errCodeData.act_code }));
  }
};


module.exports = { fetchErrorCode, sendErrorCode };
