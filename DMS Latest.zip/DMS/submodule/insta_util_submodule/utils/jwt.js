const jwt = require('jsonwebtoken');
const Logger = require('./logger');

const logger = new Logger();
const {
  ENTERING_TO, FILES, UTIL_METHOD, METHOD,
} = require('../../insta_constants_submodule/constants/constantLogger');

const secretKey = 'sdeddevew3dmkm';


const jwtSign = (payload, expiresIn = 60*40) => {
  new Logger(`${ENTERING_TO} ${FILES.JWT} ${UTIL_METHOD} ${METHOD.JWT_SIGN}`);
  return jwt.sign(payload, secretKey, {expiresIn});
};

console.log(jwtSign)

const jwtVerify = (payload) => {
  new Logger(`${ENTERING_TO} ${FILES.JWT} ${UTIL_METHOD} ${METHOD.JWT_VERIFY}`);
  return jwt.verify(payload, secretKey);
};

// 171901 start jan 16 2023
const jwtDecode = (payload) => {
  logger.debug(`${ENTERING_TO} ${FILES.JWT} ${UTIL_METHOD} jwtDecode`);
  return jwt.decode(payload)
}
// 171901 end jan 16 2023

const generateCustomId = () => {
  let result = '';
  const characters = 'abcdefghijklmnopqrstuvwxyz0123456789';
  const charactersLength = characters.length;
  for (let i = 0; i < 12; i++) {
    result += characters.charAt(Math.floor(Math.random() * charactersLength));
  }
  return result;
};

module.exports = { jwtSign, jwtVerify, jwtDecode, generateCustomId };
