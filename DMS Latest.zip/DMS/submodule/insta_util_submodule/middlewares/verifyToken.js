const Logger = require('../utils/logger');
const properties = require("../../../package.json");
const jwt = require('../utils/jwt');
const { METHOD, ERROR_MESSAGE } = require('../../insta_constants_submodule/constants/constantLogger');
const { ERROR_CODE } = require('../../../constants/constant');
const { TOKEN_EXIPRED_ERROR, STATUS_CODE } = require('../../insta_constants_submodule/constants/constant');



// const verifyToken = async (req, res, next) => {
//   const logger = new Logger(`${METHOD.VERIFY_TOKEN}`, 'AUTHORIZATION', ` ${JSON.stringify(req.headers.authorization)}`);
//   try {
//     const { authorization } = req.headers;
//     logger.debug(`REQUEST HEADER ${JSON.stringify(req.headers)} `);
//     if (authorization && authorization.startsWith('Bearer') && authorization.split(' ')[1]) {
//       const response = await jwt.jwtVerify(authorization.split(' ')[1]);
//       if (!response || !response.lead_id) {
//         logger.debug('INVALID USER');
//         res.status(STATUS_CODE.FORBIDDEN);
//         res.send();
//       } else {
//         if (!verifyData || !verifyData[0] || !verifyData[0].lead_id) {
//           logger.debug('USER NOT FOUND');
//           res.status(STATUS_CODE.FORBIDDEN);
//           res.send();
//         } else {
//           logger.debug(SUCCESS_MESSAGE.VERIFY_TOKEN);
//           req.body.leadId = req.headers.authorization;
//           req.body.lead_id = verifyData[0].lead_id.toString();
//           req.body.journeyId = verifyData[0].journey_id;
          
//         }
//       }
//     } else {
//       logger.debug('INVALID HEADER');
//       res.status(STATUS_CODE.FORBIDDEN);
//       res.send();
//     }
//   } catch (error) {
//     logger.error(`${ERROR_CODE.API_INTERNAL} | VERIFY | ${ERROR_MESSAGE.VERIFY_TOKEN} | ${JSON.stringify(error)} | ${error}`);
//     if (error.name === TOKEN_EXIPRED_ERROR) {
//       res.status(STATUS_CODE.JWT_TOKEN_EXPIRED);
//       res.send();
//     } else {
//       res.status(STATUS_CODE.FORBIDDEN);
//       res.send();
//     }
//   }
// };
































const verifyToken = async (req, res, next) => {
  const logger = new Logger(`${METHOD.VERIFY_TOKEN}`, 'AUTHORIZATION', ` ${JSON.stringify(req.headers.authorization)}`);
  try {
    const { authorization } = req.headers;
    logger.debug(`REQUEST HEADER ${JSON.stringify(req.headers)} `);

    if (authorization && authorization.startsWith('Bearer') && authorization.split(' ')[1]) {
      const token = authorization.split(' ')[1];
      const response = await jwt.jwtVerify(token); // this should return your payload (e.g., lead_id, journey_id)

      if (!response || !response.lead_id) {
        logger.debug('INVALID USER');
        return res.status(STATUS_CODE.FORBIDDEN).send();
      }

      logger.debug('VERIFY TOKEN SUCCESS');

      // Attach values to req.body for downstream use
      req.body.leadId = token;
      req.body.lead_id = response.lead_id.toString();
      req.body.journeyId = response.journey_id;

      return next(); // Proceed to next middleware or controller
    } else {
      logger.debug('INVALID HEADER');
      return res.status(STATUS_CODE.FORBIDDEN).send();
    }
  } catch (error) {
    logger.error(`${ERROR_CODE.API_INTERNAL} | VERIFY | ${ERROR_MESSAGE.VERIFY_TOKEN} | ${JSON.stringify(error)} | ${error}`);
    if (error.name === TOKEN_EXIPRED_ERROR) {
      return res.status(STATUS_CODE.JWT_TOKEN_EXPIRED).send();
    } else {
      return res.status(STATUS_CODE.FORBIDDEN).send();
    }
  }
};
























// const adminAuthorization = async (req, res, next) => {
//   const logger = new Logger(`adminAuthorization`, 'AUTHORIZATION', ` ${JSON.stringify(req.headers['x-auth'])}`);
//   try {
//     const authorization = req.headers['x-auth'];
//     logger.info(`REQUEST HEADER ${JSON.stringify(req.headers)}`);
//     if (authorization && authorization.startsWith('Bearer') && authorization.split(' ')[1]) {
//       const token = authorization.split(' ')[1];
//       const response = jwt.jwtVerify(authorization.split(' ')[1]);
//       logger.info(`response | ${JSON.stringify(response)}`);

//       const fetchUserSession = `select jwt_internal from \`employee_user_session\` emp where jwt_internal = :authorization`;
//       const valiateUserSession = await leadService.getALLDetails(fetchUserSession, { authorization: token });
//       if (!valiateUserSession || !valiateUserSession.length) return res.send({ status: 405, message: 'INVALID TOKEN' });

//       logger.info(SUCCESS_MESSAGE.VERIFY_TOKEN);
//       const sqlQuery = `UPDATE employee_user_session SET last_session_validated = CURRENT_TIMESTAMP where session_id = '${response.sessionId}'`;
//       const verifyData = await leadService.update(sqlQuery);
//       logger.info(`verifyData - ${JSON.stringify(verifyData)} `);
//       req.body.adminToken = req.headers['x-auth'];
//       req.body.adminDisplayName = response.displayName;
//       req.body.adminEmail = response.emailId;
//       next();
//     } else {
//       logger.info('INVALID HEADER');
//       res.send({ status: 405, message: 'Invalid Header' });
//     }
//   } catch (error) {
//     logger.error(`${ERROR_CODE.API_INTERNAL} | VERIFY | ${ERROR_MESSAGE.VERIFY_TOKEN} | ${JSON.stringify(error)} | ${error}`);
//     res.send({ status: 405, message: 'Token Expired' });
//   }
// };

module.exports = { verifyToken, };
