// cryptoUtils.js
const crypto = require('crypto');

const logger = require('your-logger');

const key = '31323334353637383930616263646566';
const iv = Buffer.alloc(16);

// AES-256-CBC Encryption
const encrypt256 = (data, aes256Key) => {
  logger.debug('Starting encryption...');
  let encryptionKey = aes256Key?.aes_key || key;

  // Make sure the key is a 32-byte Buffer
  const cipher = crypto.createCipheriv('aes-256-cbc', Buffer.from(encryptionKey, 'utf-8'), iv);

  const input = typeof data === 'object' ? JSON.stringify(data) : String(data);
  let encrypted = cipher.update(input, 'utf-8');
  encrypted = Buffer.concat([encrypted, cipher.final()]);

  const encryptedBase64 = encrypted.toString('base64');
  logger.debug(`Encrypted data: ${encryptedBase64}`);

  return Promise.resolve({
    iv: iv.toString('base64'),
    encryptedData: encryptedBase64,
  });
};

// AES-256-CBC Decryption
const decrypt256 = (encryptedBase64, aes256Key) => {
  logger.debug('Starting decryption...');
  let decryptionKey = aes256Key?.aes_key || key;

  const encryptedBuffer = Buffer.from(encryptedBase64, 'base64');
  const decipher = crypto.createDecipheriv('aes-256-cbc', Buffer.from(decryptionKey, 'utf-8'), iv);

  let decrypted = decipher.update(encryptedBuffer);
  decrypted = Buffer.concat([decrypted, decipher.final()]);

  const decryptedText = decrypted.toString('utf-8');
  logger.debug(`Decrypted data: ${decryptedText}`);

  return Promise.resolve({ decryptedData: decryptedText });
};

module.exports = {
  encrypt256,
  decrypt256
};
