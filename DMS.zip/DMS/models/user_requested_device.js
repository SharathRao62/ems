
module.exports = (sequelize, DataTypes) => {
    const user_requested_device = sequelize.define("user_requested_device", {
        id: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        lead_id: DataTypes.STRING,
        name: DataTypes.STRING,   //connecting mysql with node js server
        desk: DataTypes.STRING,
        floor: DataTypes.STRING,
        manager_name: DataTypes.STRING,
        email: DataTypes.STRING,
        request_id: DataTypes.STRING,
        device_name: DataTypes.STRING,
        request_date: DataTypes.DATE,
        global_rnd_no: DataTypes.STRING,
        createdTime: DataTypes.DATE,
        updatedTime: DataTypes.DATE,
    },
        {
            updatedAt: 'updatedTime',
            createdAt: 'createdTime',
            freezeTableName: true,
        });

    return user_requested_device;
}



