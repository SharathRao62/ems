
const EMAIL = {
    EMAIL_USER: "techsudo34@gmail.com",
    EMAIL_PASSWORD: "qshlopxwpynwwqmm"
};


module.exports = { EMAIL };
