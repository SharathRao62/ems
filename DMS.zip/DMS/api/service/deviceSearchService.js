const db = require('../../models');
const device = db.device;
const Sequelize = require('sequelize');
const { Op } = Sequelize;
const user_requested_device = db.user_requested_device;


const getDeviceData = (condition, columns, logger) => {
    logger.info(`getDeviceData: ${JSON.stringify(condition)}`);
    const searchConditions = columns
        .filter(column => typeof column === 'string') // Safety check
        .map(column => ({
            [column]: { [Op.like]: `%${condition}%` }
        }));

    return device.findAll({
        attributes: columns,
        where: {
            [Op.or]: searchConditions
        },
        raw: true,
    }).catch((error) => {
        logger.error(`getDeviceData | error | ${error}`);
        return []; // Ensure it doesn't break if there's an error
    });
};


const getDeviceDetails = (condition, columns, logger) => {
    logger.info(`getDeviceData: ${JSON.stringify(condition)}`);
    return user_requested_device.findOne({
        attributes: columns,
        where: condition,
        raw: true,
    }).catch((error) => {
        logger.error(`getDeviceData | error | ${error}`);
    });
};


const updateDeviceService = (condition, updateData, logger) => {
    return user_requested_device.update(updateData,
        {
            where: condition,
            individualHooks: true,
        }
    ).catch((error) => {
        logger.error(`updateDeviceService | error | ${error}`);
    });
};


const createDeviceService = async (condition, payload, logger) => {
    try {
        const dataToCreate = { ...condition, ...payload };
        const newRequest = await user_requested_device.create(dataToCreate);
        logger.info('createDeviceService | Device created successfully.');
        return newRequest;
    } catch (error) {
        logger.error(`createDeviceService | error | ${error}`);
        throw error;
    }
};



module.exports = {
    getDeviceData,
    getDeviceDetails,
    updateDeviceService,
    createDeviceService,
}