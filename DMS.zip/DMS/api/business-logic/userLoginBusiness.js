const { STATUS_CODE, ERR_MESSAGE, ERROR_CODE, UNAUTHORIZED } = require('../../constants/constant');
const { ENTERING_TO, BUSINESS_LOGIC_METHOD, METHOD } = require('../../constants/constantLogger');
const loginService = require('../service/loginService');
const Logger = require('../../submodule/insta_util_submodule/utils/logger');
const { errorFormat } = require('../../submodule/insta_util_submodule/utils/errorFormat');
const bcrypt = require('bcrypt');
const { jwtSign, generateCustomId } = require('../../submodule/insta_util_submodule/utils/jwt');

module.exports.userLogin = async (req) => {
    const logger = new Logger(`Product: EMS | Method: userLogin`);

    try {
        logger.info(` ${ENTERING_TO} | ${BUSINESS_LOGIC_METHOD} | ${METHOD.USER_LOGIN} | request |  ${JSON.stringify(req)}`);

        const condition = { email: req.email };

        let employeeData = await loginService.userLogin(condition, ['email', 'password'], logger);
        logger.info(`employeeData | ${JSON.stringify(employeeData)}`);

        if (!employeeData) {
            return {
                status: STATUS_CODE.NOT_FOUND,
                message: 'Employee not found',
            };
        }

        const hashedPasswordFromDB = employeeData.password;
        const isMatch = await bcrypt.compare(req.password, hashedPasswordFromDB);

        if (!isMatch) {
            return {
                status: STATUS_CODE.UNAUTHORIZED,
                message: 'Invalid password',
            };
        }

        const payload = {
            lead_id: generateCustomId(),
            email: employeeData.email
        };
        
        const token = jwtSign(payload);

        return {
            status: STATUS_CODE.SUCCESS,
            message: 'Logged in Successfully',
            token: token,
        }
    } catch (error) {
        logger.error(`${ERROR_CODE.API_INTERNAL} | userLogin | error | ${errorFormat(error)}`);
        return {
            status: STATUS_CODE.INTERNAL_ERROR,
            message: "Internal Error",
            error: ERR_MESSAGE.USER_LOGIN_API_FAILED,
        };
    }
};

