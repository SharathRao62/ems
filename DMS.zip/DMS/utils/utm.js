const  utmConfigurationService  = require("../api/service/utmConfigurationService");

module.exports.checkPartnerURL = async (qsParsed,logger) => {
    try {
            if (qsParsed && qsParsed.iup) {
                const data = await utmConfigurationService.fetchUTMConfiguration({ utm_source_id: qsParsed.ius, utm_product_id: qsParsed.iup }, ['configuration_bypass', 'utm_source_id']);
                logger.info(`IS UTM BUSINESS METHOD | lead | ${JSON.stringify(data)}  ${JSON.stringify(qsParsed.lead_id)}`);
                if (data.configuration_bypass) {
                    let configurationBypass = false;
                    try {
                        configurationBypass = JSON.parse(data.configuration_bypass);
                    } catch (error) {
                        logger.error(`IS UTM BUSINESS METHOD | lead |  ${JSON.stringify(qsParsed.lead_id)} | CATCH ERROR | ${JSON.stringify(error)}`);
                        configurationBypass = data.configuration_bypass;
                    }
                    if (configurationBypass?.partnershipUrl) {
                        return true;
                    }
                }
                return false;
            }
    } catch (error) {
        logger.error(`IS UTM BUSINESS METHOD | lead | ${JSON.stringify(qsParsed.lead_id)} | CATCH ERROR ${error} | ${JSON.stringify(error)}`);

        return false;
    }
}