const leadService = require('../api/service/leadService');

const leadTable = '`lead`';
const products = '`products`';
let product_details = '';

module.exports.getAccType = async(leadId)=>{
    const query3 = `SELECT products.product_name as account_type, lop.dest_prod, lead.application_no, products.product_id, person.person_id, contact.mobile_personal
    FROM ${products}
    INNER JOIN ${leadTable} ON lead.account_type = products.product_id 
    LEFT JOIN person ON lead.lead_id = person.lead_id
    LEFT JOIN contact ON lead.lead_id = contact.lead_id 
    LEFT JOIN lop ON lead.lead_id = lop.lead_id 
    WHERE lead.lead_id =:leadId LIMIT 1`;
    return product_details = await leadService.getALLDetails(query3, { leadId: leadId });

}
