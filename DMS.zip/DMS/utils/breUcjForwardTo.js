const Logger = require('../submodule/insta_util_submodule/utils/logger');
const CONSTANTS = require('../constants/constant');
const logger = new Logger();


const ucjInternalForward = (ForwardTo) => {
    logger.info(`ucjInternalForward | dateformatter  | request | ${JSON.stringify(ForwardTo)}`);
    switch (ForwardTo) {
        case "NSTP":
            return "NSTP";
        case "LC":
            return "NSTP";
        case "RC":
            return "NSTP";
        case "NON AFFLUENT":
            return "NSTP";
        case "STP":
            return "STP";
        case "":
            return "HARD REJECT";
        case "HARD REJECT":
            return "HARD REJECT";
        default:
            return(ForwardTo);
    }

}

module.exports = {
    ucjInternalForward
};
