const { ENTERING_TO, UTIL_METHOD } = require("../constants/constantLogger");
const Logger = require("../submodule/insta_util_submodule/utils/logger");

const logger = new Logger("Method: getIndexOfMaxDateFromLopBankingData");

const getIndexOfMaxDateFromLopBankingData = (data, leadId) => {
  logger.info(`leadId | ${leadId} | ${ENTERING_TO} ${UTIL_METHOD} | data: ${JSON.stringify(data)}`);
  if (!data) return;

  let maxDate = 0;
  let index = 0;

  data.forEach((val, i) => {
    const summaryDt = val.summary_dt?.split(/[/-]/).reverse().join("/");
    const date = new Date(summaryDt);
    logger.info(`leadId | ${leadId} | date after formatting | summaryDt: ${summaryDt} | date: ${date}`);

    if (date.toString() !== "Invalid Date" && date.getTime() > maxDate) {
      maxDate = date.getTime();
      index = i;
    }
  });

  logger.info(`leadId | ${leadId} | index: ${index} | data: ${JSON.stringify(data[index])}`);
  return index;
};

module.exports = {
  getIndexOfMaxDateFromLopBankingData,
};
