const { Op } = require("sequelize");

const Logger = require("../submodule/insta_util_submodule/utils/logger");

const { ENTERING_TO, UTIL_METHOD } = require("../constants/constantLogger");
const { ADDRESS_SOURCE_LIST } = require("../constants/constant");

const addressService = require("../api/service/addressService");

const getOneCompleteAddressSet = async (leadId) => {
    let completeAddressSet = null;
    const logger = new Logger("getOneCompleteAddressSet", `leadId | ${leadId}`);
    logger.info(`${ENTERING_TO} ${UTIL_METHOD}`);

    const addressDetails = await addressService.fetchMultipleAddressDetails({ lead_id: leadId, [Op.or] : { is_permanent_address: 1, is_communication_address: 1 } }, ["address_id", "address_line1", "address_line2", "address_line3", "state", "city", "pincode", "address_source", "is_permanent_address", "is_communication_address"]);
    logger.info(`addressDetails: ${JSON.stringify(addressDetails)}`);
    
    for (const addressSource of ADDRESS_SOURCE_LIST) {
        const address = addressDetails.filter(item => item.address_source?.startsWith(addressSource));

        completeAddressSet = address.find(item => item.is_permanent_address && isAddressValid(item));
        if (completeAddressSet) break;

        completeAddressSet = address.find(item => item.is_communication_address && isAddressValid(item));
        if (completeAddressSet) break;
    }

    logger.info(`completeAddressSet: ${JSON.stringify(completeAddressSet)}`);
    if (!completeAddressSet) return completeAddressSet;

    return {
        address: [completeAddressSet.address_line1, completeAddressSet.address_line2, completeAddressSet.address_line3].filter(item => item).join(", "),
        state: completeAddressSet.state,
        city: completeAddressSet.city,
        pincode: completeAddressSet.pincode
    };
};

const isAddressValid = (addressObj) => {
  if (
    addressObj && 
    addressObj.address_line1 && 
    addressObj.state && 
    addressObj.city && 
    addressObj.pincode && 
    !addressObj.pincode.split("").every(item => item === "0")
  ) {
    return true;
  }
  
  return false;
};

module.exports = {
    getOneCompleteAddressSet,
};
