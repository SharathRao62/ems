const externalApiStatusService = require("../api/service/externalApiStatusService");
const loanDetailService = require("../api/service/loanDetailService");
const breService  = require("../api/service/breService");
const { PERFIOS_PAGES, AGGREGATOR_PAGES, ADDITIONAL_DETAILS_PAGE, PERFIOS_NETBANKING_RETRIEVE_REPORT, OFFICE_EMAIL, AADHAAR_PAGES, ESIGN_PAGES, ENACH_PAGES, UPLOAD_TAB, EMPLOYMENT_TYPE, OCCUPATION_NAME,BRE2,ADDITIONAL_PAGE,ESIGN_PAGES_STP,ENACH_PAGES_STP,ESIGN_MISMATCH,VKYC_DROP,VKYC_URL } = require("../constants/constant");
const rcasService = require('../api/service/rcasService')
const onekycService = require('../api/service/onekycService');
const similarityService = require('../api/service/similarityService');

module.exports.checkPartnerLogic = async (leadId, logger, leadData, leadAttributeData, occupationData) => {
    try {
        let partnerRemark;
        logger.info(`leadData | ${JSON.stringify(leadData)}`);
        logger.info(`leadAttributeData | ${JSON.stringify(leadAttributeData)}`);
        logger.info(`occupationData | ${JSON.stringify(occupationData)}`);

        let loanDetailData = await loanDetailService.getLoanDetails({ lead_id: leadId }, ['initial_forward_to', 'forward_to'],  logger) ;
        logger.info(`lead_id | ${leadId} | RUNTIME | loanDetailData| ${JSON.stringify(loanDetailData)}`);
        let breOneDetail = await breService.getLogDetails(['lead_id'], { lead_id: leadId, service_type: 'UCJ INITIAL UNIFIED BRE' });
        logger.info(`lead_id | ${leadId} | RUNTIME | breOneDetail| ${JSON.stringify(breOneDetail)}`);
        let mccmData = await externalApiStatusService.fetchMccmStatus({ lead_id: leadId }, ['api_name', 'flag']);
        logger.info(`lead_id | ${leadId} | RUNTIME | mccmData| ${JSON.stringify(mccmData)}`);
        let nameData = await externalApiStatusService.nameMatchReport({ lead_id: leadId }, ['status']);
        logger.info(`lead_id | ${leadId} | RUNTIME | nameData| ${JSON.stringify(nameData)}`);

        let onekycData = await onekycService.getDetails(['address_colour_code'], { lead_id: leadId })
        logger.info(`lead_id | ${leadId} | RUNTIME | onekycData| ${JSON.stringify(onekycData)}`);

        let rcasData = await rcasService.getRcasDetails(['response_code'],{lead_id:leadId})
        logger.info(`lead_id | ${leadId} | RUNTIME | rcasData| ${JSON.stringify(rcasData)}`);


        let similarityData = await similarityService.getSimilarityDetails(['similarity_flag'],{lead_id:leadId})
        logger.info(`lead_id | ${leadId} | RUNTIME | similarityData| ${JSON.stringify(similarityData)}`);


        const getDataBasedonLead = (flag) => {
            let flagValue = leadAttributeData.find(({ attribute_name }) => attribute_name == flag);
            if (flagValue)
                return flagValue;
            else
                return false;
        };
        logger.info(` CRON | getDataBasedonLead| `);

        if (loanDetailData) {
            logger.info(` CRON | loanDetailData|  ${JSON.stringify(loanDetailData)}`);

            if (loanDetailData.forward_to) {

                if (loanDetailData.forward_to == "HARD REJECT" && mccmData) {
                    partnerRemark = "Reject";
                }
                else if (loanDetailData.forward_to == "NON AFFLUENT" && mccmData) {
                    partnerRemark = "Reject";
                }
                else if (loanDetailData.forward_to == "LC" && mccmData) {
                    partnerRemark = "Reject";
                }
                else if (loanDetailData.forward_to == "RC" && mccmData && leadData.stage_description == "SUCCESS_BRE2") {
                    partnerRemark = "Eligible but dropped immediate";
                }
                
                else if (loanDetailData.forward_to == "STP" && mccmData && BRE2.includes(leadData.stage_description)
                ) {
                    partnerRemark = "Eligible but ropped immediate";
                }
                else if (loanDetailData.forward_to == "STP" && mccmData && ADDITIONAL_PAGE.includes(leadData.stage_description)
                ) {
                    partnerRemark = "Eligible but dropped immediate";
                }
                else if (loanDetailData.forward_to == "STP" && mccmData && ESIGN_PAGES_STP.includes(leadData.stage_description)
                ) {
                    partnerRemark = "Eligible but eSign Pending";
                }
                else if (loanDetailData.forward_to == "STP" && mccmData && ENACH_PAGES_STP.includes(leadData.stage_description)
                ){
                    partnerRemark = "Eligible but Nach pending";
                }
                else if (loanDetailData.forward_to == "STP" && ((onekycData && onekycData.address_colour_code=='RED') || VKYC_DROP.includes(leadData.stage_description))
                ){
                    partnerRemark = "Eligible but vKYC pending";
                }
                else if (loanDetailData.forward_to == "STP" && mccmData && getDataBasedonLead('UCJ_ESIGN') && getDataBasedonLead('UCJ_ESIGN').attribute_value == 2
                ) {
                    partnerRemark = "Success";
                }

                // else if(similarityData && similarityData.similarity_flag==1
                //     ){
                //         partnerRemark = "Rejected as Name Mismatch at eSign";
                //     }
                else if (loanDetailData.forward_to == "STP" && mccmData && ESIGN_MISMATCH.includes(leadData.stage_description)
                ) {
                    partnerRemark = "Rejected as Name Mismatch at eSign";
                }
                else if(rcasData && rcasData.response_code==2
                ){
                    partnerRemark = "Eligible subject to Credit Approval";
                }
                else if(rcasData && rcasData.response_code==1
                ){
                    partnerRemark = "Eligible but resume journey";
                }

                else if (loanDetailData.forward_to == "RC" && mccmData && ADDITIONAL_DETAILS_PAGE.includes(leadData.stage_description)
                ) {
                    partnerRemark = "Eligible but dropped immediate";
                }
                else if (loanDetailData.forward_to == "RC" && mccmData && ESIGN_PAGES.includes(leadData.stage_description)
                ) {
                    partnerRemark = "Eligible but eSign Pending";
                }
                else if (loanDetailData.forward_to == "RC" && mccmData && ENACH_PAGES.includes(leadData.stage_description)
                ){
                    partnerRemark = "Eligible but Nach pending";
                }
                else if (loanDetailData.forward_to == "RC" && ((onekycData && onekycData.address_colour_code=='RED') || VKYC_URL.includes(leadData.stage_description))
                ){
                    partnerRemark = "Eligible but vKYC pending";
                }
                else if (loanDetailData.forward_to == "RC" && mccmData && getDataBasedonLead('UCJ_ESIGN') && getDataBasedonLead('UCJ_ESIGN').attribute_value == 2
                ) {
                    partnerRemark = "Success";
                }
            }   
            logger.info(` CRON | partnerRemark|  ${JSON.stringify(partnerRemark)}`);

            if (!partnerRemark) {

                if (mccmData && (AGGREGATOR_PAGES.includes(leadData.stage_description) || getDataBasedonLead('UCJ_ACT_AGGR_INIT')
                    && getDataBasedonLead('UCJ_ACT_AGGR_INIT').attribute_value == 1 || getDataBasedonLead('UCJ_ACT_AGGR_TS') && getDataBasedonLead('UCJ_ACT_AGGR_TS').attribute_value == 1 || getDataBasedonLead('UCJ_ACT_AGGR_RPT')
                    && getDataBasedonLead('UCJ_ACT_AGGR_RPT').attribute_value == 1 || getDataBasedonLead('AGGREGATOR_REDIRECTION') && getDataBasedonLead('AGGREGATOR_REDIRECTION').attribute_value == 2
                )) {
                    logger.info(` CRON | Rediredcted to Account Aggregator`);

                    partnerRemark = "Rediredcted to Account Aggregator flow but didn't complete the journey";
                }
                else if (mccmData && PERFIOS_PAGES.includes(leadData.stage_description)

                ) {
                    partnerRemark = "Rediredcted to Net banking flow but didn't complete the journey";
                }
                else if (mccmData && UPLOAD_TAB.includes(leadData.stage_description)
                ) {
                    partnerRemark = "Statement upload flow opted but not completed";
                }

                else if (mccmData && (PERFIOS_NETBANKING_RETRIEVE_REPORT.includes(leadData.stage_description) || (nameData && nameData.status == 'FAILURE'))
                ) {
                    logger.info(` CRON | Uploaded Statement & PAN`);

                    partnerRemark = "Uploaded Statement & PAN Name Mismatch. Both needs to be same.";
                }
                else if (loanDetailData.initial_forward_to) {

                    if (loanDetailData.initial_forward_to == 'HARD REJECT') {
                        partnerRemark = "Reject";
                    }
                    else if (occupationData && occupationData.occupation_name && EMPLOYMENT_TYPE.includes(occupationData.occupation_name)) {
                        partnerRemark = "Non Salaried customer";
                    }
                    else if (mccmData && occupationData && occupationData.occupation_name && OCCUPATION_NAME.includes(occupationData.occupation_name) && OFFICE_EMAIL.includes(leadData.stage_description)) {

                        partnerRemark = "Official email id verification pending";
                    } else {
                        partnerRemark = "Technical error and retry";
                    }

                } else if (!loanDetailData.initial_forward_to && (getDataBasedonLead('UNI_POSIDEX') && getDataBasedonLead('UNI_POSIDEX').attribute_value == 1 || getDataBasedonLead('UNI_BUREAU')) && AADHAAR_PAGES.includes(leadData.stage_description)) {

                    partnerRemark = "Technical error and retry";
                }
                else {

                    partnerRemark = "Technical error and retry";
                }
            }
        }else {

            partnerRemark="Technical error and retry"; 
        }
        logger.info(` CRON | final value partnerRemark|  ${JSON.stringify(partnerRemark)}`);

        return partnerRemark;

    } catch (error) {
        logger.error(`PARTNER LOGIC BUSINESS METHOD | lead | ${JSON.stringify(leadId)} | CATCH ERROR ${error} | ${JSON.stringify(error)}`);
        return false;
    }
};

