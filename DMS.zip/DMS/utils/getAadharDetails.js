const Logger = require("../submodule/insta_util_submodule/utils/logger");
const systemConf = require("../submodule/insta_util_submodule/utils/systemConfigUtils");

const aadhaarService = require("../api/service/aadhaarService");
const masterService = require("../api/service/masterService");
const { PRODUCT_NAMES, SYSTEM_CONFIG } = require("../constants/constant");
const { ENTERING_TO, UTIL_METHOD } = require("../constants/constantLogger");

const getAadharDetails = async (leadId) => {
    const logger = new Logger("getAadharDetail", `leadId | ${leadId}`);
    logger.info(`${ENTERING_TO} ${UTIL_METHOD}`);

    const sysConfigData = await systemConf.fetchMultipleSystemConfigurations(PRODUCT_NAMES.UNIFIED_HOME_LOAN, [SYSTEM_CONFIG.ENABLE_AADHAR_ADDRESS_HOMELOAN]);
    logger.info(`sysConfigData: ${JSON.stringify(sysConfigData)}`);
    
    if (!sysConfigData[SYSTEM_CONFIG.ENABLE_AADHAR_ADDRESS_HOMELOAN]) {
    
        return undefined;
    }

    const aadharData = await aadhaarService.getAadharData({ lead_id: leadId }, ["perm_address_line1", "perm_address_line2", "perm_address_line3", "perm_city", "perm_state", "perm_pincode"]);
    logger.info(`aadharData: ${JSON.stringify(aadharData)}`);

    const stateId = aadharData?.perm_pincode && await getStateId(aadharData.perm_pincode, aadharData.perm_state, leadId);
    logger.info(`stateId: ${stateId}`);

    const cityObj = aadharData?.perm_city && stateId && await masterService.getCityIdByCityNameAndStateId(stateId, aadharData.perm_city, leadId);
    logger.info(`cityObj: ${JSON.stringify(cityObj)}`);

    const aadharDetails = {
        permanent_address: [aadharData?.perm_address_line1, aadharData?.perm_address_line2, aadharData?.perm_address_line3].filter(item => item).join(", "),
        permanent_city: aadharData?.perm_city || "",
        permanent_state: aadharData?.perm_state || "",
        permanent_country: "INDIA",
        permanent_pin: aadharData?.perm_pincode || "",
        permStateId: stateId || 0,
        permCityId: cityObj?.iilm_id || 0
    };

    logger.info(`aadharDetails: ${JSON.stringify(aadharDetails)}`);
    return aadharDetails;
};

const getStateId = async (pincode, state, leadId) => {
    const logger = new Logger("getStateId", `leadId | ${leadId}`);
    logger.info(`${ENTERING_TO} ${UTIL_METHOD}`);

    const stateList = await masterService.getStateByPincode(pincode, leadId);
    logger.info(`state list | ${JSON.stringify(stateList)}`);

    if (stateList?.length === 1 && stateList?.[0]?.state_id && stateList?.[0]?.region && state && stateList[0].region.toLowerCase() === state.toLowerCase()) {
        logger.info(`valid state | ${stateList[0].state_code}`);
        return stateList[0].state_id;
    }

    return null;
};
module.exports={
    getAadharDetails,
    getStateId
}